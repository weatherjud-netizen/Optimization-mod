package com.nitrocore.client.gui;

import com.nitrocore.client.ConfigStore;
import com.nitrocore.client.NitroRuntime;
import com.nitrocore.core.Colors;
import com.nitrocore.core.Theme;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** The building blocks of every menu page. Each row knows how to measure, draw and react to input. */
public final class Rows {

	private Rows() {
	}

	/** Called after any setting changed: save later, apply the options now. */
	static void changed() {
		ConfigStore.markDirty();
		NitroRuntime.requestSync();
	}

	public static final class Metrics {
		public int rowH = 18;
		public boolean touch;
		public boolean anim = true;
	}

	public abstract static class Row {
		int x;
		int y;
		int w;
		int h;
		int relY;
		float hover;
		BooleanSupplier gate;

		public Row gate(BooleanSupplier g) {
			this.gate = g;
			return this;
		}

		final boolean enabled() {
			return gate == null || gate.getAsBoolean();
		}

		final float alpha() {
			return enabled() ? 1f : 0.38f;
		}

		abstract int measure(Gfx g, int width, Metrics m);

		abstract void render(Gfx g, int mx, int my, Metrics m, float dt);

		/** Slider-like rows react on press and keep following the pointer. */
		boolean pressDraggable(double mx, double my, Metrics m) {
			return false;
		}

		void drag(double mx, double my) {
		}

		void release() {
		}

		/** Everything else reacts on release, so a scroll swipe on a phone does not flip switches. */
		void tap(double mx, double my, int button, Metrics m) {
		}

		boolean interactive() {
			return true;
		}

		final boolean hit(double mx, double my) {
			return mx >= x && mx < x + w && my >= y && my < y + h;
		}

		final void updateHover(boolean over, float dt, Metrics m) {
			float target = over && enabled() && interactive() ? 1f : 0f;
			hover = m.anim ? hover + (target - hover) * Math.min(1f, dt * 14f) : target;
		}

		final void hoverBackground(Gfx g) {
			if (hover > 0.03f) {
				Theme th = g.theme();
				g.roundRect(x, y + 1, w, h - 2, Colors.fade(th.panelHover | 0xFF000000, hover * 0.6f));
			}
		}
	}

	// ------------------------------------------------------------------ header and text

	public static final class Header extends Row {
		private final String title;

		public Header(String title) {
			this.title = title;
		}

		@Override
		boolean interactive() {
			return false;
		}

		@Override
		int measure(Gfx g, int width, Metrics m) {
			return m.rowH - 2 + 6;
		}

		@Override
		void render(Gfx g, int mx, int my, Metrics m, float dt) {
			Theme th = g.theme();
			int ty = y + h - 11;
			g.text(title, x + 4, ty, th.accent);
			int lineX = x + 4 + g.width(title) + 6;
			g.rect(lineX, ty + 4, x + w - 4, ty + 5, Colors.withAlpha(th.accent, 90));
		}
	}

	public static final class Paragraph extends Row {
		private final String text;
		private final boolean dim;
		private final List<String> lines = new ArrayList<>();

		public Paragraph(String text, boolean dim) {
			this.text = text;
			this.dim = dim;
		}

		@Override
		boolean interactive() {
			return false;
		}

		@Override
		int measure(Gfx g, int width, Metrics m) {
			lines.clear();
			int max = width - 10;
			for (String para : text.split("\n", -1)) {
				StringBuilder line = new StringBuilder();
				for (String word : para.split(" ")) {
					String trial = line.length() == 0 ? word : line + " " + word;
					if (g.width(trial) > max && line.length() > 0) {
						lines.add(line.toString());
						line = new StringBuilder(word);
					} else {
						line = new StringBuilder(trial);
					}
				}
				lines.add(line.toString());
			}
			return lines.size() * 10 + 6;
		}

		@Override
		void render(Gfx g, int mx, int my, Metrics m, float dt) {
			Theme th = g.theme();
			int color = dim ? th.textDim : th.text;
			for (int i = 0; i < lines.size(); i++) {
				g.text(lines.get(i), x + 5, y + 3 + i * 10, color);
			}
		}
	}

	public static final class Info extends Row {
		private final String label;
		private final Supplier<String> value;
		private final Function<Theme, Integer> color;

		public Info(String label, Supplier<String> value, Function<Theme, Integer> color) {
			this.label = label;
			this.value = value;
			this.color = color;
		}

		@Override
		boolean interactive() {
			return false;
		}

		@Override
		int measure(Gfx g, int width, Metrics m) {
			return m.rowH - 4;
		}

		@Override
		void render(Gfx g, int mx, int my, Metrics m, float dt) {
			Theme th = g.theme();
			int ty = y + (h - 8) / 2;
			g.text(label, x + 5, ty, th.textDim);
			String v = g.fit(value.get(), w - g.width(label) - 20);
			g.textRight(v, x + w - 5, ty, color == null ? th.text : color.apply(th));
		}
	}

	// ------------------------------------------------------------------ toggle

	public static final class Toggle extends Row {
		private final String label;
		private final String desc;
		private final BooleanSupplier get;
		private final Consumer<Boolean> set;
		private float knob = -1f;

		public Toggle(String label, String desc, BooleanSupplier get, Consumer<Boolean> set) {
			this.label = label;
			this.desc = desc;
			this.get = get;
			this.set = set;
		}

		@Override
		int measure(Gfx g, int width, Metrics m) {
			return m.rowH + (desc == null || desc.isEmpty() ? 0 : 9);
		}

		@Override
		void render(Gfx g, int mx, int my, Metrics m, float dt) {
			Theme th = g.theme();
			float a = alpha();
			updateHover(hit(mx, my), dt, m);
			hoverBackground(g);
			boolean on = get.getAsBoolean();
			if (knob < 0f) {
				knob = on ? 1f : 0f;
			}
			float target = on ? 1f : 0f;
			knob = m.anim ? knob + (target - knob) * Math.min(1f, dt * 16f) : target;

			int trackW = m.touch ? 30 : 24;
			int trackH = m.touch ? 15 : 11;
			int tx = x + w - trackW - 5;
			int ty = y + (m.rowH - trackH) / 2;
			int track = Colors.fade(Colors.mix(th.panelHover | 0xFF000000, th.accent, knob), a);
			g.roundRect(tx, ty, trackW, trackH, trackH / 2, track);
			int ks = trackH - 4;
			int kx = tx + 2 + Math.round((trackW - trackH) * knob);
			g.roundRect(kx, ty + 2, ks, ks, ks / 2, Colors.fade(on ? th.onAccent : th.text, a));

			int textY = y + (m.rowH - 8) / 2 - (desc == null || desc.isEmpty() ? 0 : 1);
			g.text(g.fit(label, w - trackW - 18), x + 5, textY, Colors.fade(th.text, a));
			if (desc != null && !desc.isEmpty()) {
				g.text(g.fit(desc, w - 12), x + 5, y + m.rowH - 3, Colors.fade(th.textDim, a));
			}
		}

		@Override
		void tap(double mx, double my, int button, Metrics m) {
			set.accept(!get.getAsBoolean());
			changed();
		}
	}

	// ------------------------------------------------------------------ slider

	public static final class Slider extends Row {
		private final String label;
		private final int min;
		private final int max;
		private final int step;
		private final IntSupplier get;
		private final IntConsumer set;
		private final IntFunction<String> fmt;

		public Slider(String label, int min, int max, int step, IntSupplier get, IntConsumer set, IntFunction<String> fmt) {
			this.label = label;
			this.min = min;
			this.max = max;
			this.step = Math.max(1, step);
			this.get = get;
			this.set = set;
			this.fmt = fmt;
		}

		private int trackX() {
			return x + 6;
		}

		private int trackW() {
			return w - 12;
		}

		@Override
		int measure(Gfx g, int width, Metrics m) {
			return m.rowH + 8;
		}

		@Override
		void render(Gfx g, int mx, int my, Metrics m, float dt) {
			Theme th = g.theme();
			float a = alpha();
			updateHover(hit(mx, my), dt, m);
			hoverBackground(g);
			int v = get.getAsInt();
			int ty = y + 3;
			g.text(g.fit(label, w - 70), x + 5, ty, Colors.fade(th.text, a));
			g.textRight(fmt.apply(v), x + w - 5, ty, Colors.fade(th.accent, a));

			int barH = m.touch ? 6 : 4;
			int by = y + m.rowH - 2;
			int bx = trackX();
			int bw = trackW();
			g.roundRect(bx, by, bw, barH, barH / 2, Colors.fade(th.panelHover | 0xFF000000, a));
			float t = max == min ? 0f : (v - min) / (float) (max - min);
			int fillW = Math.round(bw * Math.max(0f, Math.min(1f, t)));
			g.roundRect(bx, by, Math.max(barH, fillW), barH, barH / 2, Colors.fade(th.accent, a));
			int kw = m.touch ? 6 : 4;
			int kh = barH + 4;
			g.roundRect(bx + fillW - kw / 2, by - 2, kw, kh, 1, Colors.fade(th.text, a));
		}

		private void apply(double mx) {
			float t = (float) ((mx - trackX()) / Math.max(1, trackW()));
			t = Math.max(0f, Math.min(1f, t));
			int raw = Math.round(min + t * (max - min));
			int snapped = min + Math.round((raw - min) / (float) step) * step;
			snapped = Math.max(min, Math.min(max, snapped));
			if (snapped != get.getAsInt()) {
				set.accept(snapped);
				changed();
			}
		}

		@Override
		boolean pressDraggable(double mx, double my, Metrics m) {
			apply(mx);
			return true;
		}

		@Override
		void drag(double mx, double my) {
			apply(mx);
		}
	}

	// ------------------------------------------------------------------ choice

	public static final class Choice extends Row {
		private final String label;
		private final Supplier<String[]> options;
		private final IntSupplier get;
		private final IntConsumer set;

		public Choice(String label, Supplier<String[]> options, IntSupplier get, IntConsumer set) {
			this.label = label;
			this.options = options;
			this.get = get;
			this.set = set;
		}

		private int boxW(Gfx g) {
			int widest = 0;
			for (String s : options.get()) {
				widest = Math.max(widest, g.width(s));
			}
			return widest + 26;
		}

		@Override
		int measure(Gfx g, int width, Metrics m) {
			return m.rowH;
		}

		@Override
		void render(Gfx g, int mx, int my, Metrics m, float dt) {
			Theme th = g.theme();
			float a = alpha();
			updateHover(hit(mx, my), dt, m);
			hoverBackground(g);
			String[] opts = options.get();
			int idx = Math.max(0, Math.min(opts.length - 1, get.getAsInt()));
			int bw = Math.min(boxW(g), w - 60);
			int bh = m.rowH - 4;
			int bx = x + w - bw - 5;
			int by = y + 2;
			g.roundRect(bx, by, bw, bh, Colors.fade(th.panelRaised | 0xFF000000, a));
			g.outline(bx, by, bw, bh, g.radius(), Colors.fade(th.border, a));
			int ty = y + (m.rowH - 8) / 2;
			g.text("<", bx + 5, ty, Colors.fade(th.textDim, a));
			g.text(">", bx + bw - 5 - g.width(">"), ty, Colors.fade(th.textDim, a));
			g.textCentered(g.fit(opts[idx], bw - 22), bx + bw / 2, ty, Colors.fade(th.accent, a));
			g.text(g.fit(label, w - bw - 18), x + 5, ty, Colors.fade(th.text, a));
		}

		@Override
		void tap(double mx, double my, int button, Metrics m) {
			int n = options.get().length;
			if (n == 0) {
				return;
			}
			int idx = get.getAsInt();
			boolean back = button == 1;
			set.accept(Math.floorMod(idx + (back ? -1 : 1), n));
			changed();
		}
	}

	// ------------------------------------------------------------------ chips

	public static final class Chips extends Row {
		private final String[] labels;
		private final IntSupplier selected;
		private final IntConsumer pick;
		private int[] cx = new int[0];
		private int[] cy = new int[0];
		private int[] cw = new int[0];
		private int chipH;

		public Chips(String[] labels, IntSupplier selected, IntConsumer pick) {
			this.labels = labels;
			this.selected = selected;
			this.pick = pick;
		}

		@Override
		int measure(Gfx g, int width, Metrics m) {
			cx = new int[labels.length];
			cy = new int[labels.length];
			cw = new int[labels.length];
			chipH = m.rowH - 2;
			int cursor = 4;
			int line = 0;
			for (int i = 0; i < labels.length; i++) {
				int wi = g.width(labels[i]) + 14;
				if (cursor + wi > width - 4 && cursor > 4) {
					cursor = 4;
					line++;
				}
				cx[i] = cursor;
				cy[i] = 2 + line * (chipH + 4);
				cw[i] = wi;
				cursor += wi + 4;
			}
			return 4 + (line + 1) * (chipH + 4);
		}

		@Override
		boolean interactive() {
			return true;
		}

		@Override
		void render(Gfx g, int mx, int my, Metrics m, float dt) {
			Theme th = g.theme();
			int sel = selected.getAsInt();
			for (int i = 0; i < labels.length; i++) {
				int bx = x + cx[i];
				int by = y + cy[i];
				boolean over = mx >= bx && mx < bx + cw[i] && my >= by && my < by + chipH;
				boolean on = i == sel;
				int bg = on ? (over ? th.accentHover : th.accent) : (over ? th.panelHover | 0xFF000000 : th.panelRaised | 0xFF000000);
				g.roundRect(bx, by, cw[i], chipH, bg);
				if (!on) {
					g.outline(bx, by, cw[i], chipH, g.radius(), th.border);
				}
				g.textCentered(labels[i], bx + cw[i] / 2, by + (chipH - 8) / 2, on ? th.onAccent : th.text);
			}
		}

		@Override
		void tap(double mx, double my, int button, Metrics m) {
			for (int i = 0; i < labels.length; i++) {
				int bx = x + cx[i];
				int by = y + cy[i];
				if (mx >= bx && mx < bx + cw[i] && my >= by && my < by + chipH) {
					pick.accept(i);
					changed();
					return;
				}
			}
		}
	}

	// ------------------------------------------------------------------ button

	public static final class Button extends Row {
		private final String label;
		private final Runnable action;
		private final boolean primary;

		public Button(String label, boolean primary, Runnable action) {
			this.label = label;
			this.primary = primary;
			this.action = action;
		}

		@Override
		int measure(Gfx g, int width, Metrics m) {
			return m.rowH + 4;
		}

		@Override
		void render(Gfx g, int mx, int my, Metrics m, float dt) {
			Theme th = g.theme();
			updateHover(hit(mx, my), dt, m);
			int bx = x + 4;
			int bw = w - 8;
			int by = y + 2;
			int bh = h - 4;
			int base = primary ? th.accent : (th.panelRaised | 0xFF000000);
			int hov = primary ? th.accentHover : (th.panelHover | 0xFF000000);
			g.roundRect(bx, by, bw, bh, Colors.mix(base, hov, hover));
			if (!primary) {
				g.outline(bx, by, bw, bh, g.radius(), th.border);
			}
			g.textCentered(label, x + w / 2, by + (bh - 8) / 2, primary ? th.onAccent : th.text);
		}

		@Override
		void tap(double mx, double my, int button, Metrics m) {
			action.run();
		}
	}

	// ------------------------------------------------------------------ colour picker

	public static final class ColorPicker extends Row {
		private final String label;
		private final IntSupplier get;
		private final IntConsumer set;
		private float hue;
		private float sat;
		private float val;
		private int lastRgb = -1;
		private int active = -1;

		public ColorPicker(String label, IntSupplier get, IntConsumer set) {
			this.label = label;
			this.get = get;
			this.set = set;
		}

		private int lineH(Metrics m) {
			return m.touch ? 15 : 12;
		}

		private void sync() {
			int rgb = get.getAsInt() & 0xFFFFFF;
			if (rgb != lastRgb) {
				float[] hsv = Colors.toHsv(rgb);
				if (hsv[1] > 0.001f && hsv[2] > 0.001f) {
					hue = hsv[0];
				}
				sat = hsv[1];
				val = hsv[2];
				lastRgb = rgb;
			}
		}

		@Override
		int measure(Gfx g, int width, Metrics m) {
			return m.rowH + 3 * lineH(m) + 4;
		}

		@Override
		void render(Gfx g, int mx, int my, Metrics m, float dt) {
			Theme th = g.theme();
			sync();
			int rgb = lastRgb;
			int ty = y + (m.rowH - 8) / 2;
			g.text(label, x + 5, ty, th.text);
			int sw = 26;
			int sx = x + w - sw - 5;
			g.roundRect(sx - 1, y + 2, sw + 2, m.rowH - 4, th.border);
			g.roundRect(sx, y + 3, sw, m.rowH - 6, Colors.opaque(rgb));
			g.textRight(String.format("#%06X", rgb), sx - 6, ty, th.textDim);

			int bx = x + 6;
			int bw = w - 12;
			int barH = m.touch ? 7 : 5;
			int segs = g.animated() ? Math.max(12, bw / 4) : 16;
			for (int line = 0; line < 3; line++) {
				int by = y + m.rowH + line * lineH(m) + 3;
				for (int s = 0; s < segs; s++) {
					int x1 = bx + bw * s / segs;
					int x2 = bx + bw * (s + 1) / segs;
					float t = (s + 0.5f) / segs;
					int c;
					if (line == 0) {
						c = Colors.fromHsv(t * 360f, 1f, 1f);
					} else if (line == 1) {
						c = Colors.fromHsv(hue, t, val);
					} else {
						c = Colors.fromHsv(hue, sat, t);
					}
					g.rect(x1, by, x2, by + barH, Colors.opaque(c));
				}
				float pos = line == 0 ? hue / 360f : (line == 1 ? sat : val);
				int kx = bx + Math.round(bw * Math.max(0f, Math.min(1f, pos)));
				g.rect(kx - 1, by - 2, kx + 1, by + barH + 2, 0xFFFFFFFF);
				g.rect(kx - 2, by - 2, kx - 1, by + barH + 2, 0xFF000000);
				g.rect(kx + 1, by - 2, kx + 2, by + barH + 2, 0xFF000000);
			}
		}

		@Override
		boolean pressDraggable(double mx, double my, Metrics m) {
			int local = (int) (my - (y + m.rowH));
			if (local < 0) {
				return false;
			}
			int line = local / lineH(m);
			if (line < 0 || line > 2) {
				return false;
			}
			active = line;
			drag(mx, my);
			return true;
		}

		@Override
		void drag(double mx, double my) {
			if (active < 0) {
				return;
			}
			float t = (float) ((mx - (x + 6)) / Math.max(1, w - 12));
			t = Math.max(0f, Math.min(1f, t));
			if (active == 0) {
				hue = Math.min(359.9f, t * 360f);
			} else if (active == 1) {
				sat = t;
			} else {
				val = t;
			}
			int rgb = Colors.fromHsv(hue, sat, val);
			lastRgb = rgb;
			set.accept(rgb);
			changed();
		}

		@Override
		void release() {
			active = -1;
		}
	}
}
