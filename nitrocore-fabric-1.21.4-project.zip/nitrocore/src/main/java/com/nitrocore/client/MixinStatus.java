package com.nitrocore.client;

/**
 * Remembers which injected hooks have actually run at least once. The menu shows this, so a hook
 * that another mod bypassed shows up as "waiting" instead of silently pretending to work.
 */
public final class MixinStatus {

	public static final int ENTITY = 0;
	public static final int BLOCK_ENTITY = 1;
	public static final int PARTICLE = 2;
	public static final int SPLASH = 3;
	public static final int LOADING = 4;
	public static final int COUNT = 5;

	private static final boolean[] SEEN = new boolean[COUNT];

	private MixinStatus() {
	}

	public static void hit(int id) {
		if (!SEEN[id]) {
			SEEN[id] = true;
		}
	}

	public static boolean seen(int id) {
		return SEEN[id];
	}
}
