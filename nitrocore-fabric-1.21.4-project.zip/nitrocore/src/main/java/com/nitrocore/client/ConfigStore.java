package com.nitrocore.client;

import com.nitrocore.core.Config;
import com.nitrocore.core.Theme;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Path;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/** Holds the live config and writes it to disk on a background thread so the game never stalls on I/O. */
public final class ConfigStore {

	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("nitrocore.properties");

	private static final ScheduledExecutorService WRITER = Executors.newSingleThreadScheduledExecutor(r -> {
		Thread t = new Thread(r, "NitroCore-config-writer");
		t.setDaemon(true);
		return t;
	});

	private static volatile Config current = new Config();
	private static volatile Theme theme;
	private static ScheduledFuture<?> pending;

	private ConfigStore() {
	}

	public static void load() {
		current = Config.load(FILE);
		theme = null;
	}

	public static Config get() {
		return current;
	}

	public static Theme theme() {
		Theme t = theme;
		if (t == null) {
			t = Theme.of(current);
			theme = t;
		}
		return t;
	}

	/** Coalesces bursts of changes (slider drags) into a single write shortly after the last one. */
	public static synchronized void markDirty() {
		theme = null;
		if (pending != null) {
			pending.cancel(false);
		}
		pending = WRITER.schedule(ConfigStore::writeNow, 600, TimeUnit.MILLISECONDS);
	}

	public static synchronized void flush() {
		if (pending != null) {
			pending.cancel(false);
			pending = null;
			writeNow();
		}
	}

	private static void writeNow() {
		try {
			current.copy().save(FILE);
		} catch (IOException | RuntimeException e) {
			NitroClient.LOGGER.warn("Could not save {}", FILE, e);
		}
	}
}
