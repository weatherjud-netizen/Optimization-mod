package com.nitrocore.client;

import com.nitrocore.core.Config;
import com.nitrocore.core.CullPolicy;
import net.minecraft.block.entity.BannerBlockEntity;
import net.minecraft.block.entity.BeaconBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.EndGatewayBlockEntity;
import net.minecraft.block.entity.EndPortalBlockEntity;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.AbstractDecorationEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** The decisions behind the render hooks. Kept out of the mixin classes so they stay tiny. */
public final class CullRuntime {

	private CullRuntime() {
	}

	/** x, y, z is the camera position the renderer passes in. */
	public static boolean cullEntity(Entity entity, double x, double y, double z) {
		Config c = ConfigStore.get();
		if (!c.enabled || !c.cullEntities) {
			return false;
		}
		MixinStatus.hit(MixinStatus.ENTITY);

		if (entity instanceof PlayerEntity || entity.isGlowing() || entity.hasPassengers() || entity.getVehicle() != null) {
			return false;
		}
		MinecraftClient mc = MinecraftClient.getInstance();
		if (entity == mc.player || entity == mc.getCameraEntity()) {
			return false;
		}

		int max;
		if (entity instanceof ItemEntity) {
			if (!c.cullItems) {
				return false;
			}
			max = c.distItems;
		} else if (entity instanceof ExperienceOrbEntity) {
			if (!c.cullXp) {
				return false;
			}
			max = c.distXp;
		} else if (entity instanceof ProjectileEntity) {
			if (!c.cullProjectiles) {
				return false;
			}
			max = c.distProjectiles;
		} else if (entity instanceof ArmorStandEntity) {
			if (!c.cullArmorStands) {
				return false;
			}
			max = c.distArmorStands;
		} else if (entity instanceof AbstractDecorationEntity) {
			if (!c.cullDecor) {
				return false;
			}
			max = c.distDecor;
		} else if (entity instanceof MobEntity) {
			if (!c.cullMobs) {
				return false;
			}
			max = c.distMobs;
		} else {
			max = c.distOther;
		}

		double size = Math.max(entity.getWidth(), entity.getHeight());
		return CullPolicy.farAway(entity.squaredDistanceTo(x, y, z), max, size);
	}

	public static boolean cullBlockEntity(BlockEntity be) {
		Config c = ConfigStore.get();
		if (!c.enabled || (!c.cullBlockEntities && !c.cullSmallBlockEntities)) {
			return false;
		}
		MixinStatus.hit(MixinStatus.BLOCK_ENTITY);

		// these draw something large on purpose, hiding them at 48 blocks would look like a bug
		if (be instanceof BeaconBlockEntity || be instanceof EndGatewayBlockEntity || be instanceof EndPortalBlockEntity) {
			return false;
		}
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.gameRenderer == null) {
			return false;
		}
		Vec3d cam = mc.gameRenderer.getCamera().getPos();
		BlockPos p = be.getPos();
		double dx = p.getX() + 0.5 - cam.x;
		double dy = p.getY() + 0.5 - cam.y;
		double dz = p.getZ() + 0.5 - cam.z;
		double d2 = dx * dx + dy * dy + dz * dz;

		boolean small = be instanceof SignBlockEntity || be instanceof BannerBlockEntity || be instanceof SkullBlockEntity;
		if (small && c.cullSmallBlockEntities) {
			return CullPolicy.farAway(d2, c.distSmallBlockEntities, 0.0);
		}
		if (c.cullBlockEntities) {
			return CullPolicy.farAway(d2, c.distBlockEntities, 0.0);
		}
		return false;
	}

	/** Returns true when a new particle should be dropped. */
	public static boolean cullParticle(double x, double y, double z, int liveParticles) {
		Config c = ConfigStore.get();
		if (!c.enabled) {
			return false;
		}
		MixinStatus.hit(MixinStatus.PARTICLE);
		if (c.capParticles && liveParticles >= c.particleCap) {
			return true;
		}
		if (c.cullParticleDistance) {
			MinecraftClient mc = MinecraftClient.getInstance();
			if (mc.gameRenderer == null) {
				return false;
			}
			Vec3d cam = mc.gameRenderer.getCamera().getPos();
			double dx = x - cam.x;
			double dy = y - cam.y;
			double dz = z - cam.z;
			double limit = c.distParticles;
			return dx * dx + dy * dy + dz * dz > limit * limit;
		}
		return false;
	}
}
