package com.nitrocore.client.gui;

import com.nitrocore.client.ConfigStore;
import com.nitrocore.client.NitroClient;
import com.nitrocore.client.NitroRuntime;
import com.nitrocore.core.Colors;
import com.nitrocore.core.Config;
import com.nitrocore.core.Lang;
import com.nitrocore.core.Theme;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * The NitroCore menu. It does not use vanilla widgets at all: everything is drawn by Gfx and rows,
 * which keeps it light and lets the player recolour every part of it.
 */
public final class NitroScreen extends Screen {

	private final Screen parent;
	private final Gfx g = new Gfx();
	private final Rows.Metrics metrics = new Rows.Metrics();

	private List<Pages.Tab> tabs = new ArrayList<>();
	private int tab;
	private float scroll;
	private float scrollTarget;
	private int contentHeight;

	private int px;
	private int py;
	private int pw;
	private int ph;
	private int sideW;
	private int headH;
	private int cx;
	private int cy;
	private int cw;
	private int ch;

	private Rows.Row activeRow;
	private Rows.Row tapRow;
	private double pressX;
	private double pressY;
	private double lastY;
	private int pressButton;
	private boolean swiping;
	private boolean swipeStarted;

	private float openT;
	private long lastNs;

	public NitroScreen(Screen parent) {
		super(Text.literal("NitroCore"));
		this.parent = parent;
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	protected void init() {
		NitroClient.applyLanguage(client);
		rebuild();
	}

	/** Rebuilds the pages (language change, reset). */
	void rebuild() {
		tabs = Pages.build(this);
		relayout();
	}

	/** Recomputes sizes and row positions (resize, touch mode change, tab switch). */
	void relayout() {
		Config c = ConfigStore.get();
		metrics.touch = c.touchMode;
		metrics.rowH = c.touchMode ? 24 : 18;
		metrics.anim = c.animations && !c.liteUi;

		pw = Math.min(width - 8, 500);
		ph = Math.min(height - 8, 290);
		px = (width - pw) / 2;
		py = (height - ph) / 2;
		sideW = pw < 330 ? 52 : (pw < 420 ? 66 : 82);
		headH = metrics.rowH + 6;
		cx = px + sideW + 1;
		cy = py + headH;
		cw = pw - sideW - 1;
		ch = ph - headH;

		g.beginMeasure(textRenderer, ConfigStore.theme());
		Pages.Tab t = tabs.get(tab);
		int innerW = cw - 12;
		int yy = 0;
		for (Rows.Row row : t.rows) {
			row.w = innerW;
			row.h = row.measure(g, innerW, metrics);
			row.relY = yy;
			yy += row.h;
		}
		contentHeight = yy + 6;
		clampScroll();
	}

	private int maxScroll() {
		return Math.max(0, contentHeight - ch);
	}

	private void clampScroll() {
		scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget));
		scroll = Math.max(0f, Math.min(maxScroll(), scroll));
	}

	// ------------------------------------------------------------------ drawing

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		long now = System.nanoTime();
		float dt = lastNs == 0L ? 0.016f : Math.min(0.1f, (now - lastNs) / 1.0E9f);
		lastNs = now;

		Config c = ConfigStore.get();
		Theme th = ConfigStore.theme();
		boolean lite = c.liteUi;
		metrics.anim = c.animations && !lite;
		int radius = lite ? 0 : c.cornerRadius;
		g.begin(ctx, textRenderer, th, radius, metrics.anim);

		openT = metrics.anim ? Math.min(1f, openT + dt * 7f) : 1f;
		scroll = metrics.anim ? scroll + (scrollTarget - scroll) * Math.min(1f, dt * 18f) : scrollTarget;
		clampScroll();

		g.rect(0, 0, width, height, Colors.fade(th.dim, openT));

		if (!lite) {
			g.roundRect(px - 2, py - 1, pw + 4, ph + 5, radius + 2, Colors.fade(Colors.argb(70, 0x000000), openT));
		}
		g.roundRect(px, py, pw, ph, radius, Colors.fade(th.panel, openT));
		g.outline(px, py, pw, ph, radius, Colors.fade(th.border, openT));

		drawHeader(th, c, mouseX, mouseY);
		drawSidebar(th, mouseX, mouseY);
		drawContent(th, mouseX, mouseY, dt);
	}

	private int closeSize() {
		return headH - 6;
	}

	private int closeX() {
		return px + pw - closeSize() - 4;
	}

	private int chipW() {
		return 44;
	}

	private int chipX() {
		return closeX() - chipW() - 6;
	}

	private void drawHeader(Theme th, Config c, int mx, int my) {
		g.roundRect(px + 1, py + 1, pw - 2, headH - 1, g.radius(), Colors.fade(th.panelRaised | 0xFF000000, openT));
		int ty = py + (headH - 8) / 2;
		g.textShadow("NitroCore", px + 8, ty, th.accent);
		if (pw >= 300) {
			g.text("1.0.0", px + 8 + g.width("NitroCore") + 6, ty, th.textDim);
		}

		int cxp = chipX();
		int cyp = py + 3;
		boolean overChip = mx >= cxp && mx < cxp + chipW() && my >= cyp && my < cyp + closeSize();
		String state = c.enabled ? Lang.t("on") : Lang.t("off");
		int bg = c.enabled ? (overChip ? th.accentHover : th.accent) : (overChip ? th.panelHover | 0xFF000000 : th.panel | 0xFF000000);
		g.roundRect(cxp, cyp, chipW(), closeSize(), bg);
		if (!c.enabled) {
			g.outline(cxp, cyp, chipW(), closeSize(), g.radius(), th.border);
		}
		g.textCentered(state, cxp + chipW() / 2, cyp + (closeSize() - 8) / 2, c.enabled ? th.onAccent : th.textDim);

		int xx = closeX();
		boolean overClose = mx >= xx && mx < xx + closeSize() && my >= cyp && my < cyp + closeSize();
		g.roundRect(xx, cyp, closeSize(), closeSize(), overClose ? th.bad : (th.panel | 0xFF000000));
		g.textCentered("x", xx + closeSize() / 2, cyp + (closeSize() - 8) / 2, overClose ? 0xFFFFFFFF : th.textDim);
	}

	private int tabHeight() {
		return metrics.rowH + 6;
	}

	private void drawSidebar(Theme th, int mx, int my) {
		int sy = py + headH + 4;
		int th2 = tabHeight();
		for (int i = 0; i < tabs.size(); i++) {
			int iy = sy + i * th2;
			boolean sel = i == tab;
			boolean over = mx >= px + 3 && mx < px + sideW - 2 && my >= iy && my < iy + th2 - 2;
			if (sel) {
				g.roundRect(px + 3, iy, sideW - 6, th2 - 2, th.accentSoft);
				g.rect(px + 3, iy + 3, px + 5, iy + th2 - 5, th.accent);
			} else if (over) {
				g.roundRect(px + 3, iy, sideW - 6, th2 - 2, Colors.fade(th.panelHover | 0xFF000000, 0.7f));
			}
			String label = g.fit(Lang.t(tabs.get(i).labelKey), sideW - 16);
			g.text(label, px + 9, iy + (th2 - 2 - 8) / 2, sel ? th.accent : th.text);
		}
		g.rect(px + sideW, py + headH, px + sideW + 1, py + ph - 1, Colors.fade(th.border, 0.6f));
	}

	private void drawContent(Theme th, int mx, int my, float dt) {
		g.clipStart(cx, cy, cw, ch);
		int top = cy + 2 - Math.round(scroll);
		for (Rows.Row row : tabs.get(tab).rows) {
			row.x = cx + 6;
			row.y = top + row.relY;
			if (row.y + row.h < cy || row.y > cy + ch) {
				continue;
			}
			row.render(g, mx, my, metrics, dt);
		}
		g.clipEnd();

		if (maxScroll() > 0) {
			int trackX = px + pw - 4;
			int trackTop = cy + 2;
			int trackH = ch - 4;
			g.rect(trackX, trackTop, trackX + 2, trackTop + trackH, Colors.fade(th.panelHover | 0xFF000000, 0.8f));
			int thumbH = Math.max(14, trackH * ch / contentHeight);
			int thumbY = trackTop + Math.round((trackH - thumbH) * (scroll / maxScroll()));
			g.rect(trackX, thumbY, trackX + 2, thumbY + thumbH, th.accent);
		}
	}

	// ------------------------------------------------------------------ input

	private Rows.Row rowAt(double mx, double my) {
		if (mx < cx || mx >= cx + cw || my < cy || my >= cy + ch) {
			return null;
		}
		for (Rows.Row row : tabs.get(tab).rows) {
			if (row.hit(mx, my)) {
				return row;
			}
		}
		return null;
	}

	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		Config c = ConfigStore.get();
		int cyp = py + 3;
		if (mx >= closeX() && mx < closeX() + closeSize() && my >= cyp && my < cyp + closeSize()) {
			close();
			return true;
		}
		if (mx >= chipX() && mx < chipX() + chipW() && my >= cyp && my < cyp + closeSize()) {
			c.enabled = !c.enabled;
			Rows.changed();
			return true;
		}
		int sy = py + headH + 4;
		if (mx >= px + 3 && mx < px + sideW - 2) {
			for (int i = 0; i < tabs.size(); i++) {
				int iy = sy + i * tabHeight();
				if (my >= iy && my < iy + tabHeight() - 2) {
					if (i != tab) {
						tab = i;
						scroll = 0f;
						scrollTarget = 0f;
						relayout();
					}
					return true;
				}
			}
		}
		activeRow = null;
		tapRow = null;
		swiping = false;
		swipeStarted = false;
		if (mx >= cx && mx < cx + cw && my >= cy && my < cy + ch) {
			pressX = mx;
			pressY = my;
			lastY = my;
			pressButton = button;
			swipeStarted = true;
			Rows.Row row = rowAt(mx, my);
			if (row != null && row.enabled()) {
				if (row.pressDraggable(mx, my, metrics)) {
					activeRow = row;
					swipeStarted = false;
				} else if (row.interactive()) {
					tapRow = row;
				}
			}
			return true;
		}
		return super.mouseClicked(mx, my, button);
	}

	@Override
	public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
		if (activeRow != null) {
			activeRow.drag(mx, my);
			return true;
		}
		if (swipeStarted) {
			if (!swiping && Math.abs(my - pressY) > 4) {
				swiping = true;
				tapRow = null;
			}
			if (swiping) {
				scrollTarget -= (float) (my - lastY);
				scroll = scrollTarget;
				clampScroll();
			}
			lastY = my;
			return true;
		}
		return super.mouseDragged(mx, my, button, dx, dy);
	}

	@Override
	public boolean mouseReleased(double mx, double my, int button) {
		boolean handled = activeRow != null || swipeStarted || tapRow != null;
		if (activeRow != null) {
			activeRow.release();
			activeRow = null;
		}
		if (tapRow != null && !swiping && tapRow.hit(mx, my)) {
			tapRow.tap(mx, my, pressButton, metrics);
		}
		tapRow = null;
		swiping = false;
		swipeStarted = false;
		return handled || super.mouseReleased(mx, my, button);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
		if (mx >= cx && mx < cx + cw && my >= cy && my < cy + ch) {
			scrollTarget -= (float) (vertical * 24.0);
			clampScroll();
			return true;
		}
		return super.mouseScrolled(mx, my, horizontal, vertical);
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (NitroClient.openMenuKey() != null && KeyBindingHelper.getBoundKeyOf(NitroClient.openMenuKey()).getCode() == keyCode) {
			close();
			return true;
		}
		if (keyCode == 266) { // page up
			scrollTarget -= ch - 20;
			clampScroll();
			return true;
		}
		if (keyCode == 267) { // page down
			scrollTarget += ch - 20;
			clampScroll();
			return true;
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public void close() {
		if (client != null) {
			client.setScreen(parent);
		}
	}

	@Override
	public void removed() {
		ConfigStore.flush();
		NitroRuntime.requestSync();
	}
}
