package com.nitrocore.client;

import com.nitrocore.client.gui.Gfx;
import com.nitrocore.core.Colors;
import com.nitrocore.core.Config;
import com.nitrocore.core.FrameStats;
import com.nitrocore.core.Governor;
import com.nitrocore.core.Lang;
import com.nitrocore.core.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/** Small performance read-out. Text is rebuilt four times a second, not every frame. */
public final class HudOverlay {

	private static final FrameStats STATS = new FrameStats(240);
	private static final Gfx GFX = new Gfx();
	private static final String[] LINES = new String[6];
	private static final int[] COLORS = new int[6];
	private static int lineCount;
	private static long lastFrameNs;
	private static long lastBuildNs;

	private HudOverlay() {
	}

	public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
		Config c = ConfigStore.get();
		if (!c.enabled || !c.hud) {
			lastFrameNs = 0L;
			return;
		}
		long now = System.nanoTime();
		if (lastFrameNs != 0L) {
			STATS.record((now - lastFrameNs) / 1_000_000f);
		}
		lastFrameNs = now;

		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.options.hudHidden || mc.world == null) {
			return;
		}
		Theme th = ConfigStore.theme();
		if (now - lastBuildNs > 250_000_000L || lineCount == 0) {
			lastBuildNs = now;
			build(mc, c, th);
		}

		GFX.begin(ctx, mc.textRenderer, th, c.cornerRadius, false);
		int lineH = 10;
		int w = 0;
		for (int i = 0; i < lineCount; i++) {
			w = Math.max(w, GFX.width(LINES[i]));
		}
		int boxW = w + 10;
		int boxH = lineCount * lineH + 6;
		int sw = ctx.getScaledWindowWidth();
		int sh = ctx.getScaledWindowHeight();
		int x = (c.hudCorner & 1) == 0 ? 4 : sw - boxW - 4;
		int y = (c.hudCorner & 2) == 0 ? 4 : sh - boxH - 4;

		float alpha = c.hudOpacity / 100f;
		GFX.roundRect(x, y, boxW, boxH, Colors.fade(th.panel, alpha));
		GFX.roundRect(x, y, 2, boxH, Colors.fade(th.accent, alpha));
		for (int i = 0; i < lineCount; i++) {
			GFX.text(LINES[i], x + 6, y + 4 + i * lineH, COLORS[i]);
		}
	}

	private static void build(MinecraftClient mc, Config c, Theme th) {
		int n = 0;
		int fps = mc.getCurrentFps();
		String first = "FPS " + fps;
		if (c.hudLows && STATS.samples() > 30) {
			first += "  avg " + Math.round(STATS.averageFps()) + "  low " + Math.round(STATS.onePercentLowFps());
		}
		LINES[n] = first;
		COLORS[n++] = fps >= c.targetFps ? th.good : (fps >= c.targetFps * 0.7 ? th.warn : th.bad);

		if (c.hudFrameTime && STATS.samples() > 0) {
			LINES[n] = String.format("%s %.1f ms", Lang.t("hud.frame"), STATS.averageMs());
			COLORS[n++] = th.text;
		}
		if (c.hudMemory) {
			long used = MemoryProbe.usedBytes() >> 20;
			long max = MemoryProbe.maxBytes() >> 20;
			int pct = max > 0 ? (int) (used * 100 / max) : 0;
			LINES[n] = Lang.t("hud.mem") + " " + used + "/" + max + " MB (" + pct + "%)";
			int live = MemoryProbe.liveAfterGcPercent();
			COLORS[n++] = (c.memoryWarning && live >= c.memoryWarnPercent) ? th.bad : th.text;
		}
		if (c.hudEntities && mc.world != null) {
			LINES[n] = Lang.t("hud.ent") + " " + mc.world.getRegularEntityCount() + "  " + Lang.t("hud.part") + " " + mc.particleManager.getDebugString();
			COLORS[n++] = th.text;
		}
		if (c.hudLevel && c.adaptive) {
			int lv = NitroRuntime.level();
			LINES[n] = Lang.t("hud.adapt") + " " + lv + "/" + Governor.MAX_LEVEL + "  (" + c.targetFps + ")";
			COLORS[n++] = lv == 0 ? th.good : th.warn;
		}
		lineCount = n;
	}
}
