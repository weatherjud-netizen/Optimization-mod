package com.nitrocore.client.gui;

import com.nitrocore.core.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * Thin drawing layer over DrawContext: rounded rectangles built from plain fills (cheap enough for
 * weak phones), text helpers and scissoring. One instance is reused, call begin() before drawing.
 */
public final class Gfx {

	private DrawContext ctx;
	private TextRenderer tr;
	private Theme theme;
	private int radius;
	private boolean animated;

	public void begin(DrawContext context, TextRenderer textRenderer, Theme th, int cornerRadius, boolean animations) {
		this.ctx = context;
		this.tr = textRenderer;
		this.theme = th;
		this.radius = Math.max(0, cornerRadius);
		this.animated = animations;
	}

	/** Enough state for measuring text before any drawing happens (layout pass). */
	public void beginMeasure(TextRenderer textRenderer, Theme th) {
		this.ctx = null;
		this.tr = textRenderer;
		this.theme = th;
	}

	public Theme theme() {
		return theme;
	}

	public int radius() {
		return radius;
	}

	public boolean animated() {
		return animated;
	}

	public DrawContext context() {
		return ctx;
	}

	// ---------------------------------------------------------------- shapes

	public void rect(int x1, int y1, int x2, int y2, int color) {
		if (x2 > x1 && y2 > y1) {
			ctx.fill(x1, y1, x2, y2, color);
		}
	}

	public void gradientV(int x1, int y1, int x2, int y2, int top, int bottom) {
		if (x2 > x1 && y2 > y1) {
			ctx.fillGradient(x1, y1, x2, y2, top, bottom);
		}
	}

	public void roundRect(int x, int y, int w, int h, int color) {
		roundRect(x, y, w, h, radius, color);
	}

	public void roundRect(int x, int y, int w, int h, int r, int color) {
		if (w <= 0 || h <= 0) {
			return;
		}
		int rr = Math.min(r, Math.min(w, h) / 2);
		if (rr <= 0) {
			ctx.fill(x, y, x + w, y + h, color);
			return;
		}
		ctx.fill(x, y + rr, x + w, y + h - rr, color);
		for (int i = 0; i < rr; i++) {
			int inset = inset(rr, i);
			ctx.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
			ctx.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
		}
	}

	/** One pixel outline that follows the same corner shape as roundRect. */
	public void outline(int x, int y, int w, int h, int r, int color) {
		if (w <= 1 || h <= 1) {
			return;
		}
		int rr = Math.min(r, Math.min(w, h) / 2);
		if (rr <= 0) {
			ctx.fill(x, y, x + w, y + 1, color);
			ctx.fill(x, y + h - 1, x + w, y + h, color);
			ctx.fill(x, y + 1, x + 1, y + h - 1, color);
			ctx.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
			return;
		}
		int topInset = inset(rr, 0);
		ctx.fill(x + topInset, y, x + w - topInset, y + 1, color);
		ctx.fill(x + topInset, y + h - 1, x + w - topInset, y + h, color);
		ctx.fill(x, y + rr, x + 1, y + h - rr, color);
		ctx.fill(x + w - 1, y + rr, x + w, y + h - rr, color);
		int prev = topInset;
		for (int i = 1; i < rr; i++) {
			int in = inset(rr, i);
			int span = Math.max(1, prev - in);
			ctx.fill(x + in, y + i, x + in + span, y + i + 1, color);
			ctx.fill(x + w - in - span, y + i, x + w - in, y + i + 1, color);
			ctx.fill(x + in, y + h - 1 - i, x + in + span, y + h - i, color);
			ctx.fill(x + w - in - span, y + h - 1 - i, x + w - in, y + h - i, color);
			prev = in;
		}
	}

	private static int inset(int r, int row) {
		double dy = r - row - 0.5;
		return r - (int) Math.round(Math.sqrt(Math.max(0.0, (double) r * r - dy * dy)));
	}

	// ---------------------------------------------------------------- text

	public int width(String s) {
		return tr.getWidth(s);
	}

	public void text(String s, int x, int y, int color) {
		ctx.drawText(tr, s, x, y, color, false);
	}

	public void textShadow(String s, int x, int y, int color) {
		ctx.drawText(tr, s, x, y, color, true);
	}

	public void textCentered(String s, int centerX, int y, int color) {
		ctx.drawText(tr, s, centerX - tr.getWidth(s) / 2, y, color, false);
	}

	public void textRight(String s, int rightX, int y, int color) {
		ctx.drawText(tr, s, rightX - tr.getWidth(s), y, color, false);
	}

	/** Shortens text with dots so it fits the given pixel width. */
	public String fit(String s, int maxWidth) {
		if (maxWidth <= 0) {
			return "";
		}
		if (tr.getWidth(s) <= maxWidth) {
			return s;
		}
		int dots = tr.getWidth("...");
		return tr.trimToWidth(s, Math.max(0, maxWidth - dots)) + "...";
	}

	// ---------------------------------------------------------------- clipping

	public void clipStart(int x, int y, int w, int h) {
		ctx.enableScissor(x, y, x + w, y + h);
	}

	public void clipEnd() {
		ctx.disableScissor();
	}
}
