package com.nitrocore.client;

import com.nitrocore.client.gui.NitroScreen;
import com.nitrocore.core.Config;
import com.nitrocore.core.Lang;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class NitroClient implements ClientModInitializer {

	public static final String MOD_ID = "nitrocore";
	public static final Logger LOGGER = LoggerFactory.getLogger("NitroCore");

	private static KeyBinding openMenuKey;

	public static KeyBinding openMenuKey() {
		return openMenuKey;
	}

	@Override
	public void onInitializeClient() {
		ConfigStore.load();

		openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
			"key.nitrocore.menu", InputUtil.Type.KEYSYM, InputUtil.GLFW_KEY_RIGHT_SHIFT, "key.categories.nitrocore"));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			applyLanguage(client);
			while (openMenuKey.wasPressed()) {
				if (client.currentScreen == null) {
					client.setScreen(new NitroScreen(null));
				}
			}
			NitroRuntime.tick(client);
		});

		HudRenderCallback.EVENT.register(HudOverlay::render);

		ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
			if (!ConfigStore.get().menuButton) {
				return;
			}
			if (screen instanceof TitleScreen || screen instanceof GameMenuScreen) {
				ButtonWidget button = ButtonWidget.builder(Text.literal("NitroCore"), b -> client.setScreen(new NitroScreen(screen)))
					.dimensions(4, 4, 62, 16)
					.build();
				Screens.getButtons(screen).add(button);
			}
		});

		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> NitroRuntime.requestSync());

		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
			NitroRuntime.restore(client);
			ConfigStore.flush();
		});

		LOGGER.info("NitroCore loaded");
	}

	private static String lastConfigLang;
	private static String lastGameLang;

	/** Language comes from the config, or from the game language when set to auto. */
	public static void applyLanguage(MinecraftClient client) {
		Config c = ConfigStore.get();
		String game = client.options == null ? null : client.options.language;
		if (c.language.equals(lastConfigLang) && java.util.Objects.equals(game, lastGameLang)) {
			return;
		}
		lastConfigLang = c.language;
		lastGameLang = game;
		boolean ru;
		if ("ru".equalsIgnoreCase(c.language)) {
			ru = true;
		} else if ("en".equalsIgnoreCase(c.language)) {
			ru = false;
		} else {
			ru = game != null && game.toLowerCase().startsWith("ru");
		}
		Lang.setRussian(ru);
	}
}
