package com.nitrocore.client;

import com.nitrocore.core.Colors;
import com.nitrocore.core.Config;
import com.nitrocore.core.Lang;
import com.nitrocore.core.Theme;
import com.nitrocore.core.Tips;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Drawing for the styled loading bar and the world loading screen. */
public final class LoadingArt {

	private LoadingArt() {
	}

	/** Fills a progress bar between the given corners. No text here: fonts are not ready during the first reload. */
	public static void bar(DrawContext ctx, int x1, int y1, int x2, int y2, float progress, float opacity) {
		Config c = ConfigStore.get();
		Theme th = ConfigStore.theme();
		float p = Math.max(0f, Math.min(1f, progress));
		int w = x2 - x1;
		int h = y2 - y1;
		if (w <= 4 || h <= 2) {
			return;
		}
		ctx.fill(x1 - 1, y1 - 1, x2 + 1, y2 + 1, Colors.fade(Colors.opaque(th.border), opacity));
		ctx.fill(x1, y1, x2, y2, Colors.fade(0xFF0B0D12, opacity));
		int fill = Math.round(w * p);
		if (fill > 0) {
			ctx.fillGradient(x1, y1, x1 + fill, y2, Colors.fade(th.accentHover, opacity), Colors.fade(th.accent, opacity));
			if (c.animations && !c.liteUi && fill > 16) {
				int stripe = 14;
				int pos = (int) ((System.currentTimeMillis() / 9L) % (fill + stripe)) - stripe;
				int sx1 = Math.max(x1, x1 + pos);
				int sx2 = Math.min(x1 + fill, x1 + pos + stripe);
				if (sx2 > sx1) {
					ctx.fill(sx1, y1, sx2, y2, Colors.fade(Colors.argb(70, 0xFFFFFF), opacity));
				}
			}
		}
	}

	public static void worldLoading(DrawContext ctx, int percent) {
		MinecraftClient mc = MinecraftClient.getInstance();
		TextRenderer tr = mc.textRenderer;
		Config c = ConfigStore.get();
		Theme th = ConfigStore.theme();
		int w = ctx.getScaledWindowWidth();
		int h = ctx.getScaledWindowHeight();
		int pct = Math.max(0, Math.min(100, percent));

		int bgRgb = c.bgColor & 0xFFFFFF;
		int top = Colors.opaque(Colors.mix(Colors.opaque(bgRgb), 0xFF000000, 0.25f) & 0xFFFFFF);
		int bottom = Colors.opaque(Colors.mix(Colors.opaque(bgRgb), Colors.opaque(c.accentColor), 0.16f) & 0xFFFFFF);
		ctx.fillGradient(0, 0, w, h, top, bottom);

		int cx = w / 2;
		int cy = h / 2;
		ctx.drawCenteredTextWithShadow(tr, "NitroCore", cx, cy - 36, th.accent);
		ctx.drawCenteredTextWithShadow(tr, Lang.t("load.world"), cx, cy - 22, th.text);

		int barW = Math.min(w - 40, 220);
		int x1 = cx - barW / 2;
		bar(ctx, x1, cy - 6, x1 + barW, cy + 4, pct / 100f, 1f);
		ctx.drawCenteredTextWithShadow(tr, pct + "%", cx, cy + 10, th.text);

		String tip = Tips.pick((int) (System.currentTimeMillis() / 6000L), Lang.isRussian());
		ctx.drawCenteredTextWithShadow(tr, tr.trimToWidth(tip, w - 20), cx, h - 24, th.textDim);
	}
}
