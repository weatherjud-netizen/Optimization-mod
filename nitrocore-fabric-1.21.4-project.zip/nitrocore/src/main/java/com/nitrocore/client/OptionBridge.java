package com.nitrocore.client;

import com.nitrocore.core.Config;
import com.nitrocore.core.QualityPlan;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.particle.ParticlesMode;

/**
 * Applies the planned quality to the vanilla options and puts the player's own values back when
 * the plan no longer asks for a change. If the player edits an option by hand while we manage
 * it, that edit becomes the new baseline instead of being fought.
 */
final class OptionBridge {

	private QualityPlan.State baseline;
	private QualityPlan.State applied;

	void sync(MinecraftClient mc, Config cfg, int level) {
		GameOptions o = mc.options;
		if (o == null) {
			return;
		}
		QualityPlan.State cur = read(o);
		if (baseline == null) {
			baseline = cur.copy();
			applied = cur.copy();
		} else {
			adopt(cur);
		}
		QualityPlan.State target = QualityPlan.compute(cfg, baseline, level);
		write(o, cur, target);
		applied = read(o);
	}

	/** Puts every managed option back to what the player had. */
	void restore(MinecraftClient mc) {
		if (baseline == null || mc.options == null) {
			baseline = null;
			applied = null;
			return;
		}
		GameOptions o = mc.options;
		write(o, read(o), baseline);
		baseline = null;
		applied = null;
	}

	private void adopt(QualityPlan.State cur) {
		if (cur.viewDistance != applied.viewDistance) {
			baseline.viewDistance = cur.viewDistance;
		}
		if (Math.abs(cur.entityScale - applied.entityScale) > 1.0E-6) {
			baseline.entityScale = cur.entityScale;
		}
		if (cur.particles != applied.particles) {
			baseline.particles = cur.particles;
		}
		if (cur.clouds != applied.clouds) {
			baseline.clouds = cur.clouds;
		}
		if (cur.shadows != applied.shadows) {
			baseline.shadows = cur.shadows;
		}
		if (cur.biomeBlend != applied.biomeBlend) {
			baseline.biomeBlend = cur.biomeBlend;
		}
		if (cur.blur != applied.blur) {
			baseline.blur = cur.blur;
		}
	}

	private static QualityPlan.State read(GameOptions o) {
		QualityPlan.State s = new QualityPlan.State();
		s.viewDistance = o.getViewDistance().getValue();
		s.entityScale = o.getEntityDistanceScaling().getValue();
		s.particles = particlesToInt(o.getParticles().getValue());
		s.clouds = cloudsToInt(o.getCloudRenderMode().getValue());
		s.shadows = o.getEntityShadows().getValue();
		s.biomeBlend = o.getBiomeBlendRadius().getValue();
		s.blur = o.getMenuBackgroundBlurriness().getValue();
		return s;
	}

	private static void write(GameOptions o, QualityPlan.State cur, QualityPlan.State t) {
		if (cur.viewDistance != t.viewDistance) {
			o.getViewDistance().setValue(t.viewDistance);
		}
		if (Math.abs(cur.entityScale - t.entityScale) > 1.0E-6) {
			o.getEntityDistanceScaling().setValue(t.entityScale);
		}
		if (cur.particles != t.particles) {
			o.getParticles().setValue(intToParticles(t.particles));
		}
		if (cur.clouds != t.clouds) {
			o.getCloudRenderMode().setValue(intToClouds(t.clouds));
		}
		if (cur.shadows != t.shadows) {
			o.getEntityShadows().setValue(t.shadows);
		}
		if (cur.blur != t.blur) {
			o.getMenuBackgroundBlurriness().setValue(t.blur);
		}
		// changing the biome blend radius makes the game rebuild its chunks, so it only runs on a real change
		if (cur.biomeBlend != t.biomeBlend) {
			o.getBiomeBlendRadius().setValue(t.biomeBlend);
		}
	}

	private static int particlesToInt(ParticlesMode m) {
		if (m == ParticlesMode.ALL) {
			return QualityPlan.PARTICLES_ALL;
		}
		if (m == ParticlesMode.DECREASED) {
			return QualityPlan.PARTICLES_DECREASED;
		}
		return QualityPlan.PARTICLES_MINIMAL;
	}

	private static ParticlesMode intToParticles(int v) {
		return switch (v) {
			case QualityPlan.PARTICLES_ALL -> ParticlesMode.ALL;
			case QualityPlan.PARTICLES_DECREASED -> ParticlesMode.DECREASED;
			default -> ParticlesMode.MINIMAL;
		};
	}

	private static int cloudsToInt(CloudRenderMode m) {
		if (m == CloudRenderMode.OFF) {
			return QualityPlan.CLOUDS_OFF;
		}
		if (m == CloudRenderMode.FAST) {
			return QualityPlan.CLOUDS_FAST;
		}
		return QualityPlan.CLOUDS_FANCY;
	}

	private static CloudRenderMode intToClouds(int v) {
		return switch (v) {
			case QualityPlan.CLOUDS_OFF -> CloudRenderMode.OFF;
			case QualityPlan.CLOUDS_FAST -> CloudRenderMode.FAST;
			default -> CloudRenderMode.FANCY;
		};
	}
}
