package com.nitrocore.client;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryType;
import java.lang.management.MemoryUsage;

/** Heap numbers for the HUD and the low-memory warning. */
public final class MemoryProbe {

	private MemoryProbe() {
	}

	public static long usedBytes() {
		Runtime r = Runtime.getRuntime();
		return r.totalMemory() - r.freeMemory();
	}

	public static long maxBytes() {
		return Runtime.getRuntime().maxMemory();
	}

	/**
	 * Percentage of the maximum heap still in use right after the last garbage collection, which is
	 * a much better "is memory really short" signal than the raw used value. Returns -1 when the
	 * JVM does not report it.
	 */
	public static int liveAfterGcPercent() {
		try {
			long max = maxBytes();
			if (max <= 0 || max == Long.MAX_VALUE) {
				return -1;
			}
			long live = 0;
			boolean any = false;
			for (MemoryPoolMXBean pool : ManagementFactory.getMemoryPoolMXBeans()) {
				if (pool.getType() != MemoryType.HEAP) {
					continue;
				}
				MemoryUsage u = pool.getCollectionUsage();
				if (u != null) {
					live += Math.max(0, u.getUsed());
					any = true;
				}
			}
			if (!any) {
				return -1;
			}
			return (int) Math.min(100, live * 100 / max);
		} catch (Throwable t) {
			return -1;
		}
	}
}
