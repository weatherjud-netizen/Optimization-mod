package com.nitrocore.client;

import com.nitrocore.core.Config;
import com.nitrocore.core.Governor;
import com.nitrocore.core.Lang;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;

/** Once-per-second housekeeping: adaptive quality, option sync and the memory warning. */
public final class NitroRuntime {

	private static final int WARMUP_SECONDS = 15;
	private static final int WARN_CONFIRM_SECONDS = 3;
	private static final long WARN_GAP_MS = 90_000L;

	private static final OptionBridge BRIDGE = new OptionBridge();
	private static final Governor GOVERNOR = new Governor();

	private static int ticks;
	private static ClientWorld lastWorld;
	private static int warmup = WARMUP_SECONDS;
	private static int memHigh;
	private static long lastWarn;
	private static volatile boolean syncRequested;

	private NitroRuntime() {
	}

	public static int level() {
		return GOVERNOR.level();
	}

	/** Called by the menu after a setting changed so the effect is visible right away. */
	public static void requestSync() {
		syncRequested = true;
	}

	public static void tick(MinecraftClient mc) {
		Config c = ConfigStore.get();

		if (mc.world != lastWorld) {
			lastWorld = mc.world;
			GOVERNOR.reset();
			warmup = WARMUP_SECONDS;
			syncRequested = true;
		}

		ticks++;
		boolean second = ticks % 20 == 0;
		if (!second && !syncRequested) {
			return;
		}
		syncRequested = false;

		int level = 0;
		if (c.enabled && c.adaptive && mc.world != null) {
			if (second && !mc.isPaused() && mc.isWindowFocused()) {
				if (warmup > 0) {
					warmup--;
				} else {
					GOVERNOR.update(mc.getCurrentFps(), c.targetFps);
				}
			}
			level = GOVERNOR.level();
		} else {
			GOVERNOR.reset();
		}
		BRIDGE.sync(mc, c, level);

		if (second) {
			checkMemory(mc, c);
		}
	}

	private static void checkMemory(MinecraftClient mc, Config c) {
		if (!c.enabled || !c.memoryWarning || mc.player == null) {
			memHigh = 0;
			return;
		}
		int pct = MemoryProbe.liveAfterGcPercent();
		if (pct >= c.memoryWarnPercent) {
			memHigh++;
		} else {
			memHigh = 0;
		}
		long now = System.currentTimeMillis();
		if (memHigh >= WARN_CONFIRM_SECONDS && now - lastWarn > WARN_GAP_MS) {
			lastWarn = now;
			mc.player.sendMessage(Text.literal(Lang.t("mem.warn") + " " + pct + "%"), true);
		}
	}

	/** Hands the player's own option values back (menu switch off, game closing). */
	public static void restore(MinecraftClient mc) {
		GOVERNOR.reset();
		BRIDGE.restore(mc);
	}
}
