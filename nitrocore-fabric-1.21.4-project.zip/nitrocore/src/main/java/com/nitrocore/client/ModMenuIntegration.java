package com.nitrocore.client;

import com.nitrocore.client.gui.NitroScreen;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/** Puts the NitroCore menu behind the config button of the Mods screen. */
public final class ModMenuIntegration implements ModMenuApi {

	@Override
	public ConfigScreenFactory<?> getModConfigScreenFactory() {
		return NitroScreen::new;
	}
}
