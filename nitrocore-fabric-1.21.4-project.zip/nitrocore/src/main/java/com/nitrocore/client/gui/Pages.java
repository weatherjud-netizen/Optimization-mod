package com.nitrocore.client.gui;

import com.nitrocore.client.ConfigStore;
import com.nitrocore.client.MemoryProbe;
import com.nitrocore.client.MixinStatus;
import com.nitrocore.client.NitroRuntime;
import com.nitrocore.core.Config;
import com.nitrocore.core.Governor;
import com.nitrocore.core.Lang;
import com.nitrocore.core.Preset;
import com.nitrocore.core.ThemePreset;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import com.nitrocore.core.Theme;

/** Defines what each menu tab contains. */
final class Pages {

	private Pages() {
	}

	static final class Tab {
		final String labelKey;
		final List<Rows.Row> rows;

		Tab(String labelKey, List<Rows.Row> rows) {
			this.labelKey = labelKey;
			this.rows = rows;
		}
	}

	static List<Tab> build(NitroScreen screen) {
		Config c = ConfigStore.get();
		List<Tab> tabs = new ArrayList<>();
		tabs.add(new Tab("tab.home", home(c)));
		tabs.add(new Tab("tab.cull", cull(c)));
		tabs.add(new Tab("tab.adapt", adaptive(c)));
		tabs.add(new Tab("tab.tweaks", tweaks(c)));
		tabs.add(new Tab("tab.hud", hud(c)));
		tabs.add(new Tab("tab.style", style(c, screen)));
		tabs.add(new Tab("tab.about", about(c, screen)));
		return tabs;
	}

	private static String blocks(int v) {
		return v + " " + Lang.t("u.blocks");
	}

	private static Rows.Toggle toggle(String label, String desc, Config c, java.util.function.BooleanSupplier get, java.util.function.Consumer<Boolean> set) {
		return new Rows.Toggle(label, desc, get, set);
	}

	// ------------------------------------------------------------------ home

	private static List<Rows.Row> home(Config c) {
		List<Rows.Row> r = new ArrayList<>();
		r.add(new Rows.Toggle(Lang.t("master.label"), Lang.t("master.desc"), () -> c.enabled, v -> c.enabled = v));

		r.add(new Rows.Header(Lang.t("h.presets")));
		Preset[] presets = Preset.values();
		String[] names = new String[presets.length];
		for (int i = 0; i < presets.length; i++) {
			names[i] = Lang.isRussian() ? presets[i].ru : presets[i].en;
		}
		r.add(new Rows.Chips(names, () -> Preset.byName(c.preset).ordinal(), i -> presets[i].apply(c)));
		r.add(new Rows.Paragraph(Lang.t("home.presetnote"), true));

		r.add(new Rows.Header(Lang.t("h.status")));
		r.add(new Rows.Info(Lang.t("st.adapt"), () -> c.enabled && c.adaptive ? NitroRuntime.level() + " / " + Governor.MAX_LEVEL : Lang.t("st.na"),
			th -> NitroRuntime.level() == 0 ? th.good : th.warn));
		r.add(new Rows.Info(Lang.t("st.fps"), () -> String.valueOf(MinecraftClient.getInstance().getCurrentFps()), null));
		r.add(new Rows.Info(Lang.t("st.mem"), () -> {
			int p = MemoryProbe.liveAfterGcPercent();
			return p < 0 ? Lang.t("st.na") : p + "%";
		}, th -> {
			int p = MemoryProbe.liveAfterGcPercent();
			return p >= ConfigStore.get().memoryWarnPercent ? th.bad : th.text;
		}));
		r.add(hook("st.hook.entity", MixinStatus.ENTITY));
		r.add(hook("st.hook.be", MixinStatus.BLOCK_ENTITY));
		r.add(hook("st.hook.particle", MixinStatus.PARTICLE));
		r.add(hook("st.hook.splash", MixinStatus.SPLASH));
		r.add(hook("st.hook.loading", MixinStatus.LOADING));
		r.add(new Rows.Paragraph(Lang.t("home.hooknote"), true));
		return r;
	}

	private static Rows.Info hook(String key, int id) {
		Function<Theme, Integer> color = th -> MixinStatus.seen(id) ? th.good : th.textDim;
		return new Rows.Info(Lang.t(key), () -> MixinStatus.seen(id) ? Lang.t("st.active") : Lang.t("st.wait"), color);
	}

	// ------------------------------------------------------------------ culling

	private static List<Rows.Row> cull(Config c) {
		List<Rows.Row> r = new ArrayList<>();
		r.add(new Rows.Header(Lang.t("h.entities")));
		r.add(new Rows.Toggle(Lang.t("cull.all"), Lang.t("cull.alldesc"), () -> c.cullEntities, v -> c.cullEntities = v));
		entity(r, c, "cull.mobs", () -> c.cullMobs, v -> c.cullMobs = v, () -> c.distMobs, v -> c.distMobs = v, 16, 256);
		entity(r, c, "cull.items", () -> c.cullItems, v -> c.cullItems = v, () -> c.distItems, v -> c.distItems = v, 8, 128);
		entity(r, c, "cull.xp", () -> c.cullXp, v -> c.cullXp = v, () -> c.distXp, v -> c.distXp = v, 8, 128);
		entity(r, c, "cull.proj", () -> c.cullProjectiles, v -> c.cullProjectiles = v, () -> c.distProjectiles, v -> c.distProjectiles = v, 16, 256);
		entity(r, c, "cull.stands", () -> c.cullArmorStands, v -> c.cullArmorStands = v, () -> c.distArmorStands, v -> c.distArmorStands = v, 8, 256);
		entity(r, c, "cull.decor", () -> c.cullDecor, v -> c.cullDecor = v, () -> c.distDecor, v -> c.distDecor = v, 8, 256);
		r.add(new Rows.Slider(Lang.t("cull.other"), 16, 384, 8, () -> c.distOther, v -> c.distOther = v, Pages::blocks).gate(() -> c.cullEntities));
		r.add(new Rows.Paragraph(Lang.t("cull.note"), true));

		r.add(new Rows.Header(Lang.t("h.blockents")));
		r.add(new Rows.Toggle(Lang.t("be.all"), Lang.t("be.alldesc"), () -> c.cullBlockEntities, v -> c.cullBlockEntities = v));
		r.add(new Rows.Slider(Lang.t("distance"), 8, 192, 4, () -> c.distBlockEntities, v -> c.distBlockEntities = v, Pages::blocks).gate(() -> c.cullBlockEntities));
		r.add(new Rows.Toggle(Lang.t("be.small"), null, () -> c.cullSmallBlockEntities, v -> c.cullSmallBlockEntities = v));
		r.add(new Rows.Slider(Lang.t("distance"), 4, 96, 2, () -> c.distSmallBlockEntities, v -> c.distSmallBlockEntities = v, Pages::blocks).gate(() -> c.cullSmallBlockEntities));

		r.add(new Rows.Header(Lang.t("h.particles")));
		r.add(new Rows.Toggle(Lang.t("pt.dist"), null, () -> c.cullParticleDistance, v -> c.cullParticleDistance = v));
		r.add(new Rows.Slider(Lang.t("distance"), 8, 128, 2, () -> c.distParticles, v -> c.distParticles = v, Pages::blocks).gate(() -> c.cullParticleDistance));
		r.add(new Rows.Toggle(Lang.t("pt.cap"), null, () -> c.capParticles, v -> c.capParticles = v));
		r.add(new Rows.Slider(Lang.t("pt.capval"), 200, 8000, 100, () -> c.particleCap, v -> c.particleCap = v, String::valueOf).gate(() -> c.capParticles));
		return r;
	}

	private static void entity(List<Rows.Row> r, Config c, String key, java.util.function.BooleanSupplier on, java.util.function.Consumer<Boolean> setOn,
		java.util.function.IntSupplier dist, java.util.function.IntConsumer setDist, int min, int max) {
		r.add(new Rows.Toggle(Lang.t(key), null, on, setOn).gate(() -> c.cullEntities));
		r.add(new Rows.Slider(Lang.t("distance"), min, max, 4, dist, setDist, Pages::blocks).gate(() -> c.cullEntities && on.getAsBoolean()));
	}

	// ------------------------------------------------------------------ adaptive

	private static List<Rows.Row> adaptive(Config c) {
		List<Rows.Row> r = new ArrayList<>();
		r.add(new Rows.Toggle(Lang.t("ad.on"), Lang.t("ad.ondesc"), () -> c.adaptive, v -> c.adaptive = v));
		r.add(new Rows.Slider(Lang.t("ad.target"), 20, 240, 5, () -> c.targetFps, v -> c.targetFps = v, v -> v + " FPS").gate(() -> c.adaptive));
		r.add(new Rows.Info(Lang.t("ad.now"), () -> c.enabled && c.adaptive ? NitroRuntime.level() + " / " + Governor.MAX_LEVEL : Lang.t("st.na"),
			th -> NitroRuntime.level() == 0 ? th.good : th.warn));
		r.add(new Rows.Toggle(Lang.t("ad.rd"), null, () -> c.adaptiveRenderDistance, v -> c.adaptiveRenderDistance = v).gate(() -> c.adaptive));
		r.add(new Rows.Slider(Lang.t("ad.mind"), 2, 24, 1, () -> c.adaptiveMinDistance, v -> c.adaptiveMinDistance = v, v -> v + " " + Lang.t("u.chunks"))
			.gate(() -> c.adaptive && c.adaptiveRenderDistance));
		r.add(new Rows.Toggle(Lang.t("ad.ent"), null, () -> c.adaptiveEntities, v -> c.adaptiveEntities = v).gate(() -> c.adaptive));
		r.add(new Rows.Toggle(Lang.t("ad.part"), null, () -> c.adaptiveParticles, v -> c.adaptiveParticles = v).gate(() -> c.adaptive));
		r.add(new Rows.Toggle(Lang.t("ad.cloud"), null, () -> c.adaptiveClouds, v -> c.adaptiveClouds = v).gate(() -> c.adaptive));
		r.add(new Rows.Paragraph(Lang.t("ad.note"), true));
		return r;
	}

	// ------------------------------------------------------------------ tweaks

	private static List<Rows.Row> tweaks(Config c) {
		List<Rows.Row> r = new ArrayList<>();
		r.add(new Rows.Toggle(Lang.t("tw.blur"), Lang.t("tw.blurdesc"), () -> c.forceMenuBlurOff, v -> c.forceMenuBlurOff = v));
		r.add(new Rows.Toggle(Lang.t("tw.shadows"), null, () -> c.forceEntityShadowsOff, v -> c.forceEntityShadowsOff = v));
		r.add(new Rows.Toggle(Lang.t("tw.clouds"), null, () -> c.forceCloudsOff, v -> c.forceCloudsOff = v));
		r.add(new Rows.Toggle(Lang.t("tw.particles"), null, () -> c.reduceParticles, v -> c.reduceParticles = v));
		r.add(new Rows.Toggle(Lang.t("tw.biome"), null, () -> c.capBiomeBlend, v -> c.capBiomeBlend = v));
		r.add(new Rows.Slider(Lang.t("tw.biomeval"), 0, 7, 1, () -> c.biomeBlendMax, v -> c.biomeBlendMax = v, String::valueOf).gate(() -> c.capBiomeBlend));
		r.add(new Rows.Paragraph(Lang.t("tw.note"), true));
		return r;
	}

	// ------------------------------------------------------------------ hud

	private static List<Rows.Row> hud(Config c) {
		List<Rows.Row> r = new ArrayList<>();
		r.add(new Rows.Toggle(Lang.t("hud.on"), null, () -> c.hud, v -> c.hud = v));
		r.add(new Rows.Choice(Lang.t("hud.corner"),
			() -> new String[] {Lang.t("hud.tl"), Lang.t("hud.tr"), Lang.t("hud.bl"), Lang.t("hud.br")},
			() -> c.hudCorner, v -> c.hudCorner = v).gate(() -> c.hud));
		r.add(new Rows.Slider(Lang.t("hud.opacity"), 20, 100, 5, () -> c.hudOpacity, v -> c.hudOpacity = v, v -> v + "%").gate(() -> c.hud));
		r.add(new Rows.Toggle(Lang.t("hud.showframe"), null, () -> c.hudFrameTime, v -> c.hudFrameTime = v).gate(() -> c.hud));
		r.add(new Rows.Toggle(Lang.t("hud.showlows"), null, () -> c.hudLows, v -> c.hudLows = v).gate(() -> c.hud));
		r.add(new Rows.Toggle(Lang.t("hud.showmem"), null, () -> c.hudMemory, v -> c.hudMemory = v).gate(() -> c.hud));
		r.add(new Rows.Toggle(Lang.t("hud.showent"), null, () -> c.hudEntities, v -> c.hudEntities = v).gate(() -> c.hud));
		r.add(new Rows.Toggle(Lang.t("hud.showlvl"), null, () -> c.hudLevel, v -> c.hudLevel = v).gate(() -> c.hud));
		r.add(new Rows.Toggle(Lang.t("hud.warn"), null, () -> c.memoryWarning, v -> c.memoryWarning = v));
		r.add(new Rows.Slider(Lang.t("hud.warnpct"), 50, 98, 1, () -> c.memoryWarnPercent, v -> c.memoryWarnPercent = v, v -> v + "%").gate(() -> c.memoryWarning));
		r.add(new Rows.Paragraph(Lang.t("hud.note"), true));
		return r;
	}

	// ------------------------------------------------------------------ style

	private static List<Rows.Row> style(Config c, NitroScreen screen) {
		List<Rows.Row> r = new ArrayList<>();
		r.add(new Rows.Header(Lang.t("h.theme")));
		ThemePreset[] themes = ThemePreset.values();
		String[] names = new String[themes.length];
		for (int i = 0; i < themes.length; i++) {
			names[i] = Lang.isRussian() ? themes[i].ru : themes[i].en;
		}
		r.add(new Rows.Chips(names, () -> ThemePreset.byName(c.themePreset).ordinal(), i -> themes[i].apply(c)));
		r.add(new Rows.ColorPicker(Lang.t("st.accent"), () -> c.accentColor, v -> c.accentColor = v));
		r.add(new Rows.ColorPicker(Lang.t("st.bg"), () -> c.bgColor, v -> c.bgColor = v));
		r.add(new Rows.ColorPicker(Lang.t("st.text"), () -> c.textColor, v -> c.textColor = v));
		r.add(new Rows.Slider(Lang.t("st.alpha"), 120, 255, 5, () -> c.panelAlpha, v -> c.panelAlpha = v, v -> (v * 100 / 255) + "%"));
		r.add(new Rows.Slider(Lang.t("st.radius"), 0, 6, 1, () -> c.cornerRadius, v -> c.cornerRadius = v, String::valueOf));

		r.add(new Rows.Header(Lang.t("h.interface")));
		r.add(new Rows.Toggle(Lang.t("st.anim"), null, () -> c.animations, v -> c.animations = v));
		r.add(new Rows.Toggle(Lang.t("st.lite"), Lang.t("st.litedesc"), () -> c.liteUi, v -> c.liteUi = v));
		r.add(new Rows.Toggle(Lang.t("st.touch"), Lang.t("st.touchdesc"), () -> c.touchMode, v -> {
			c.touchMode = v;
			screen.relayout();
		}));
		r.add(new Rows.Toggle(Lang.t("st.button"), null, () -> c.menuButton, v -> c.menuButton = v));
		r.add(new Rows.Choice(Lang.t("st.lang"),
			() -> new String[] {Lang.t("st.langauto"), "English", "Русский"},
			() -> "en".equalsIgnoreCase(c.language) ? 1 : ("ru".equalsIgnoreCase(c.language) ? 2 : 0),
			v -> {
				c.language = v == 1 ? "en" : (v == 2 ? "ru" : "auto");
				com.nitrocore.client.NitroClient.applyLanguage(MinecraftClient.getInstance());
				screen.rebuild();
			}));

		r.add(new Rows.Header(Lang.t("h.loading")));
		r.add(new Rows.Toggle(Lang.t("st.splash"), null, () -> c.splashBar, v -> c.splashBar = v));
		r.add(new Rows.Toggle(Lang.t("st.loading"), null, () -> c.customLoading, v -> c.customLoading = v));
		r.add(new Rows.Paragraph(Lang.t("st.key"), true));
		return r;
	}

	// ------------------------------------------------------------------ about

	private static List<Rows.Row> about(Config c, NitroScreen screen) {
		List<Rows.Row> r = new ArrayList<>();
		r.add(new Rows.Paragraph("NitroCore 1.0.0   Minecraft 1.21.4", false));
		r.add(new Rows.Paragraph(Lang.t("ab.author"), false));
		r.add(new Rows.Paragraph(Lang.t("ab.desc"), true));

		r.add(new Rows.Header(Lang.t("h.jvm")));
		long heapMb = MemoryProbe.maxBytes() >> 20;
		r.add(new Rows.Info(Lang.t("ab.heap"), () -> heapMb + " MB", th -> heapMb < 2048 ? th.warn : th.good));
		r.add(new Rows.Paragraph(heapMb < 2048 ? Lang.t("ab.heaplow") : Lang.t("ab.heapok"), true));
		r.add(new Rows.Paragraph(Lang.t("ab.flags"), true));

		r.add(new Rows.Header(Lang.t("h.reset")));
		r.add(new Rows.Button(Lang.t("ab.resetopt"), false, () -> {
			Preset.BALANCED.apply(c);
			Rows.changed();
		}));
		r.add(new Rows.Button(Lang.t("ab.resetall"), false, () -> {
			c.copyFrom(new Config());
			c.sanitize();
			Rows.changed();
			screen.rebuild();
		}));
		return r;
	}
}
