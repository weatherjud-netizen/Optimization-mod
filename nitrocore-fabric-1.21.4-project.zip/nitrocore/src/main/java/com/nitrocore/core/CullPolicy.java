package com.nitrocore.core;

/** Distance rule shared by the entity and block entity culling. */
public final class CullPolicy {

	private CullPolicy() {
	}

	/**
	 * True when something at the given squared distance should be skipped. Big things stay visible
	 * from further away: every block of size adds eight blocks of allowance, so a dragon or a boss
	 * is never hidden at a distance where a chicken would be.
	 */
	public static boolean farAway(double distanceSq, double maxDistance, double size) {
		if (!(distanceSq >= 0.0) || Double.isInfinite(distanceSq)) {
			return false;
		}
		double limit = maxDistance + Math.max(0.0, size) * 8.0;
		return distanceSq > limit * limit;
	}
}
