package com.nitrocore.core;

/** Small ARGB helpers. All colors are 0xAARRGGBB unless a method says it takes plain RGB. */
public final class Colors {

	private Colors() {
	}

	public static int argb(int alpha, int rgb) {
		return (clamp255(alpha) << 24) | (rgb & 0xFFFFFF);
	}

	public static int opaque(int rgb) {
		return 0xFF000000 | (rgb & 0xFFFFFF);
	}

	public static int alphaOf(int argb) {
		return (argb >>> 24) & 0xFF;
	}

	public static int withAlpha(int argb, int alpha) {
		return (clamp255(alpha) << 24) | (argb & 0xFFFFFF);
	}

	/** Multiplies the alpha channel by a factor in 0..1. */
	public static int fade(int argb, float factor) {
		float f = Math.max(0f, Math.min(1f, factor));
		return withAlpha(argb, Math.round(alphaOf(argb) * f));
	}

	public static int mix(int a, int b, float t) {
		float k = Math.max(0f, Math.min(1f, t));
		int aa = lerp(alphaOf(a), alphaOf(b), k);
		int rr = lerp((a >> 16) & 0xFF, (b >> 16) & 0xFF, k);
		int gg = lerp((a >> 8) & 0xFF, (b >> 8) & 0xFF, k);
		int bb = lerp(a & 0xFF, b & 0xFF, k);
		return (aa << 24) | (rr << 16) | (gg << 8) | bb;
	}

	public static int lighten(int argb, float amount) {
		return mix(argb, withAlpha(0xFFFFFF, alphaOf(argb)), amount);
	}

	public static int darken(int argb, float amount) {
		return mix(argb, withAlpha(0x000000, alphaOf(argb)), amount);
	}

	public static float luminance(int rgb) {
		float r = ((rgb >> 16) & 0xFF) / 255f;
		float g = ((rgb >> 8) & 0xFF) / 255f;
		float b = (rgb & 0xFF) / 255f;
		return 0.2126f * r + 0.7152f * g + 0.0722f * b;
	}

	/** Dark text for bright backgrounds, light text for dark ones. */
	public static int readableOn(int rgb) {
		return luminance(rgb) > 0.6f ? 0xFF10141B : 0xFFFFFFFF;
	}

	/** Returns {h in 0..360, s in 0..1, v in 0..1}. */
	public static float[] toHsv(int rgb) {
		float r = ((rgb >> 16) & 0xFF) / 255f;
		float g = ((rgb >> 8) & 0xFF) / 255f;
		float b = (rgb & 0xFF) / 255f;
		float max = Math.max(r, Math.max(g, b));
		float min = Math.min(r, Math.min(g, b));
		float d = max - min;
		float h;
		if (d == 0f) {
			h = 0f;
		} else if (max == r) {
			h = 60f * (((g - b) / d) % 6f);
		} else if (max == g) {
			h = 60f * (((b - r) / d) + 2f);
		} else {
			h = 60f * (((r - g) / d) + 4f);
		}
		if (h < 0f) {
			h += 360f;
		}
		float s = max == 0f ? 0f : d / max;
		return new float[] {h, s, max};
	}

	public static int fromHsv(float h, float s, float v) {
		float hh = ((h % 360f) + 360f) % 360f;
		float ss = Math.max(0f, Math.min(1f, s));
		float vv = Math.max(0f, Math.min(1f, v));
		float c = vv * ss;
		float x = c * (1f - Math.abs(((hh / 60f) % 2f) - 1f));
		float m = vv - c;
		float r;
		float g;
		float b;
		if (hh < 60f) {
			r = c; g = x; b = 0f;
		} else if (hh < 120f) {
			r = x; g = c; b = 0f;
		} else if (hh < 180f) {
			r = 0f; g = c; b = x;
		} else if (hh < 240f) {
			r = 0f; g = x; b = c;
		} else if (hh < 300f) {
			r = x; g = 0f; b = c;
		} else {
			r = c; g = 0f; b = x;
		}
		int ri = Math.round((r + m) * 255f);
		int gi = Math.round((g + m) * 255f);
		int bi = Math.round((b + m) * 255f);
		return (clamp255(ri) << 16) | (clamp255(gi) << 8) | clamp255(bi);
	}

	private static int lerp(int a, int b, float t) {
		return clamp255(Math.round(a + (b - a) * t));
	}

	private static int clamp255(int v) {
		return Math.max(0, Math.min(255, v));
	}
}
