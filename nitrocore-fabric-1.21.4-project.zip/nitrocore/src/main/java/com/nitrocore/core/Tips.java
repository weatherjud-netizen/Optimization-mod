package com.nitrocore.core;

/** Short hints shown on the loading screens. */
public final class Tips {

	private Tips() {
	}

	private static final String[] EN = {
		"Press Right Shift in game to open the NitroCore menu.",
		"The adaptive mode lowers quality only while the frame rate is below your target.",
		"Presets only change optimization settings, never your colours.",
		"On a phone, use the NitroCore button on the title or pause screen.",
		"Turn on the HUD to watch frame time and memory while you tune.",
		"Culling hides what is far away, so the gain grows with busy worlds.",
		"Give the game enough memory in the launcher, but not all of your RAM.",
		"Every feature has its own switch, nothing is forced on you."
	};

	private static final String[] RU = {
		"Нажми правый Shift в игре, чтобы открыть меню NitroCore.",
		"Адаптивный режим снижает качество только пока FPS ниже цели.",
		"Пресеты меняют только оптимизацию, цвета остаются твоими.",
		"На телефоне открывай меню кнопкой NitroCore на экране заголовка или паузы.",
		"Включи HUD, чтобы видеть время кадра и память при настройке.",
		"Отсечение прячет то, что далеко, так что выигрыш растёт в насыщенных мирах.",
		"Выдели игре достаточно памяти в лаунчере, но не всю оперативку.",
		"У каждой функции свой переключатель, ничего не навязывается."
	};

	public static String pick(int seed, boolean russian) {
		String[] list = russian ? RU : EN;
		int i = Math.floorMod(seed, list.length);
		return list[i];
	}

	public static int count() {
		return EN.length;
	}
}
