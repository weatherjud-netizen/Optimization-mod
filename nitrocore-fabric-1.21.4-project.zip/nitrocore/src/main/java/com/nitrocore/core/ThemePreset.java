package com.nitrocore.core;

/** Ready-made colour schemes for the menu. Picking one only changes the three base colours. */
public enum ThemePreset {
	MIDNIGHT("Midnight", "Полночь", 0x4DA3FF, 0x0E1117, 0xE8EEF7),
	OCEAN("Ocean", "Океан", 0x2DD4BF, 0x0A1620, 0xE3F4F4),
	SUNSET("Sunset", "Закат", 0xFF8A4C, 0x1A1015, 0xFBEDE6),
	EMERALD("Emerald", "Изумруд", 0x4ADE80, 0x0C1511, 0xE6F5EC),
	ROSE("Rose", "Роза", 0xF472B6, 0x1A0F17, 0xFBE8F2),
	VIOLET("Violet", "Фиолет", 0xA78BFA, 0x120F1E, 0xEEE9FB),
	MONO("Mono", "Моно", 0xE5E7EB, 0x101010, 0xF3F4F6),
	DAYLIGHT("Daylight", "День", 0x2563EB, 0xF1F4F9, 0x141A24);

	public final String en;
	public final String ru;
	public final int accent;
	public final int background;
	public final int text;

	ThemePreset(String en, String ru, int accent, int background, int text) {
		this.en = en;
		this.ru = ru;
		this.accent = accent;
		this.background = background;
		this.text = text;
	}

	public static ThemePreset byName(String name) {
		for (ThemePreset t : values()) {
			if (t.name().equalsIgnoreCase(name)) {
				return t;
			}
		}
		return MIDNIGHT;
	}

	public void apply(Config c) {
		c.themePreset = name();
		c.accentColor = accent;
		c.bgColor = background;
		c.textColor = text;
	}
}
