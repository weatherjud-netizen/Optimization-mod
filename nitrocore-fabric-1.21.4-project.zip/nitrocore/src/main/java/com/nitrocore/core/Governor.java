package com.nitrocore.core;

/**
 * Decides, once per second, whether quality should step down or back up so the frame rate stays
 * near the target. Stepping down reacts fast, stepping up is slow and backs off when it keeps
 * failing, so the settings do not flip back and forth.
 */
public final class Governor {

	public static final int MAX_LEVEL = 4;

	private static final int DEGRADE_AFTER = 3;
	private static final int IMPROVE_HEADROOM_AFTER = 8;
	private static final int PROBE_START = 30;
	private static final int PROBE_MAX = 240;
	private static final int COOLDOWN = 5;
	private static final int QUICK_FAIL_WINDOW = 20;
	private static final int STABLE_RESET = 300;

	private int level;
	private int below;
	private int headroom;
	private int atTarget;
	private int cooldown;
	private int probeInterval = PROBE_START;
	private int sinceImprove = Integer.MAX_VALUE / 2;
	private int stableFor;

	public int level() {
		return level;
	}

	public void reset() {
		level = 0;
		below = 0;
		headroom = 0;
		atTarget = 0;
		cooldown = 0;
		probeInterval = PROBE_START;
		sinceImprove = Integer.MAX_VALUE / 2;
		stableFor = 0;
	}

	/** Feed one measured frame rate per second; returns the level that should be active now. */
	public int update(int fps, int targetFps) {
		if (sinceImprove < Integer.MAX_VALUE / 2) {
			sinceImprove++;
		}
		if (cooldown > 0) {
			cooldown--;
		}
		if (fps <= 0) {
			return level;
		}
		boolean low = fps < targetFps * 0.92;
		boolean roomy = fps >= targetFps * 1.35;
		boolean ok = fps >= targetFps * 0.97;

		if (low) {
			below++;
			headroom = 0;
			atTarget = 0;
			stableFor = 0;
		} else {
			below = 0;
			stableFor++;
			headroom = roomy ? headroom + 1 : 0;
			atTarget = ok ? atTarget + 1 : 0;
		}

		if (cooldown == 0) {
			if (below >= DEGRADE_AFTER && level < MAX_LEVEL) {
				if (sinceImprove <= QUICK_FAIL_WINDOW) {
					probeInterval = Math.min(PROBE_MAX, probeInterval * 2);
				}
				level++;
				afterChange();
			} else if (level > 0 && (headroom >= IMPROVE_HEADROOM_AFTER || atTarget >= probeInterval)) {
				level--;
				sinceImprove = 0;
				afterChange();
			}
		}
		if (stableFor >= STABLE_RESET) {
			probeInterval = PROBE_START;
		}
		return level;
	}

	private void afterChange() {
		below = 0;
		headroom = 0;
		atTarget = 0;
		cooldown = COOLDOWN;
	}
}
