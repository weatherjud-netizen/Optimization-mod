package com.nitrocore.core;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * All user settings. Plain public fields on purpose: the GUI binds to them directly and
 * the file format is derived from the field names by reflection, so adding a setting is one line.
 */
public final class Config {

	public static final int VERSION = 1;

	public int configVersion = VERSION;

	// ---- general ----
	public boolean enabled = true;
	public String preset = "BALANCED";
	public String language = "auto";

	// ---- entity culling ----
	@Opt public boolean cullEntities = true;
	@Opt public boolean cullMobs = true;
	@Opt public int distMobs = 96;
	@Opt public boolean cullItems = true;
	@Opt public int distItems = 48;
	@Opt public boolean cullXp = true;
	@Opt public int distXp = 32;
	@Opt public boolean cullProjectiles = true;
	@Opt public int distProjectiles = 64;
	@Opt public boolean cullArmorStands = true;
	@Opt public int distArmorStands = 64;
	@Opt public boolean cullDecor = true;
	@Opt public int distDecor = 64;
	@Opt public int distOther = 128;

	// ---- block entity culling ----
	@Opt public boolean cullBlockEntities = true;
	@Opt public int distBlockEntities = 48;
	@Opt public boolean cullSmallBlockEntities = true;
	@Opt public int distSmallBlockEntities = 24;

	// ---- particles ----
	@Opt public boolean cullParticleDistance = true;
	@Opt public int distParticles = 40;
	@Opt public boolean capParticles = true;
	@Opt public int particleCap = 2500;

	// ---- adaptive quality ----
	@Opt public boolean adaptive = true;
	@Opt public int targetFps = 60;
	@Opt public boolean adaptiveRenderDistance = true;
	@Opt public int adaptiveMinDistance = 6;
	@Opt public boolean adaptiveEntities = true;
	@Opt public boolean adaptiveParticles = true;
	@Opt public boolean adaptiveClouds = true;

	// ---- fixed option tweaks ----
	@Opt public boolean forceMenuBlurOff = true;
	@Opt public boolean forceEntityShadowsOff = false;
	@Opt public boolean forceCloudsOff = false;
	@Opt public boolean reduceParticles = false;
	@Opt public boolean capBiomeBlend = false;
	@Opt public int biomeBlendMax = 2;

	// ---- HUD ----
	public boolean hud = false;
	public int hudCorner = 0;
	public int hudOpacity = 85;
	public boolean hudFrameTime = true;
	public boolean hudLows = true;
	public boolean hudMemory = true;
	public boolean hudEntities = true;
	public boolean hudLevel = true;
	public boolean memoryWarning = true;
	public int memoryWarnPercent = 88;

	// ---- interface ----
	public String themePreset = "MIDNIGHT";
	public int accentColor = 0x4DA3FF;
	public int bgColor = 0x0E1117;
	public int textColor = 0xE8EEF7;
	public int panelAlpha = 238;
	public int cornerRadius = 3;
	public boolean animations = true;
	public boolean liteUi = false;
	public boolean touchMode = false;
	public boolean menuButton = true;

	// ---- loading screens ----
	public boolean splashBar = true;
	public boolean customLoading = true;

	// ------------------------------------------------------------------

	private static List<Field> fields() {
		List<Field> out = new ArrayList<>();
		for (Field f : Config.class.getFields()) {
			int m = f.getModifiers();
			if (Modifier.isStatic(m) || Modifier.isFinal(m)) {
				continue;
			}
			out.add(f);
		}
		return out;
	}

	public Config copy() {
		Config c = new Config();
		c.copyFrom(this);
		return c;
	}

	public void copyFrom(Config other) {
		for (Field f : fields()) {
			try {
				f.set(this, f.get(other));
			} catch (IllegalAccessException e) {
				throw new IllegalStateException(e);
			}
		}
	}

	/** Copies only the fields marked as optimization settings. */
	public void copyOptimizationFrom(Config other) {
		for (Field f : fields()) {
			if (f.isAnnotationPresent(Opt.class)) {
				try {
					f.set(this, f.get(other));
				} catch (IllegalAccessException e) {
					throw new IllegalStateException(e);
				}
			}
		}
	}

	public void resetOptimizationDefaults() {
		copyOptimizationFrom(new Config());
	}

	public boolean sameAs(Config other) {
		for (Field f : fields()) {
			try {
				if (!f.get(this).equals(f.get(other))) {
					return false;
				}
			} catch (IllegalAccessException e) {
				throw new IllegalStateException(e);
			}
		}
		return true;
	}

	/** Pulls every value back into a range the rest of the code can rely on. */
	public void sanitize() {
		configVersion = VERSION;
		distMobs = clamp(distMobs, 16, 512);
		distItems = clamp(distItems, 8, 512);
		distXp = clamp(distXp, 8, 512);
		distProjectiles = clamp(distProjectiles, 16, 512);
		distArmorStands = clamp(distArmorStands, 8, 512);
		distDecor = clamp(distDecor, 8, 512);
		distOther = clamp(distOther, 16, 512);
		distBlockEntities = clamp(distBlockEntities, 8, 256);
		distSmallBlockEntities = clamp(distSmallBlockEntities, 4, 256);
		distParticles = clamp(distParticles, 8, 256);
		particleCap = clamp(particleCap, 200, 12000);
		targetFps = clamp(targetFps, 20, 240);
		adaptiveMinDistance = clamp(adaptiveMinDistance, 2, 32);
		biomeBlendMax = clamp(biomeBlendMax, 0, 7);
		hudCorner = clamp(hudCorner, 0, 3);
		hudOpacity = clamp(hudOpacity, 20, 100);
		memoryWarnPercent = clamp(memoryWarnPercent, 50, 98);
		panelAlpha = clamp(panelAlpha, 120, 255);
		cornerRadius = clamp(cornerRadius, 0, 6);
		accentColor &= 0xFFFFFF;
		bgColor &= 0xFFFFFF;
		textColor &= 0xFFFFFF;
		if (preset == null) {
			preset = "BALANCED";
		}
		if (themePreset == null) {
			themePreset = "MIDNIGHT";
		}
		if (language == null) {
			language = "auto";
		}
	}

	private static int clamp(int v, int lo, int hi) {
		return Math.max(lo, Math.min(hi, v));
	}

	// ------------------------------------------------------------------ persistence

	public static Config load(Path file) {
		Config c = new Config();
		if (!Files.isRegularFile(file)) {
			return c;
		}
		Properties p = new Properties();
		try (BufferedReader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
			p.load(r);
		} catch (IOException | IllegalArgumentException e) {
			return c;
		}
		for (Field f : fields()) {
			String raw = p.getProperty(f.getName());
			if (raw == null) {
				continue;
			}
			raw = raw.trim();
			try {
				Class<?> t = f.getType();
				if (t == boolean.class) {
					f.setBoolean(c, Boolean.parseBoolean(raw));
				} else if (t == int.class) {
					f.setInt(c, Integer.decode(raw));
				} else if (t == String.class) {
					f.set(c, raw);
				}
			} catch (NumberFormatException | IllegalAccessException ignored) {
				// keep the default for a value that cannot be read
			}
		}
		c.sanitize();
		return c;
	}

	public void save(Path file) throws IOException {
		sanitize();
		StringBuilder sb = new StringBuilder(2048);
		sb.append("# NitroCore settings. Edit in game with the menu (Right Shift by default).\n");
		for (Field f : fields()) {
			try {
				Object v = f.get(this);
				String text;
				if (f.getType() == int.class && f.getName().endsWith("Color")) {
					text = String.format("#%06X", ((Integer) v) & 0xFFFFFF);
				} else {
					text = String.valueOf(v);
				}
				sb.append(f.getName()).append('=').append(text).append('\n');
			} catch (IllegalAccessException e) {
				throw new IllegalStateException(e);
			}
		}
		Path parent = file.toAbsolutePath().getParent();
		if (parent != null) {
			Files.createDirectories(parent);
		}
		Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
		try (BufferedWriter w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
			w.write(sb.toString());
		}
		try {
			Files.move(tmp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException atomicNotSupported) {
			Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
		}
	}
}
