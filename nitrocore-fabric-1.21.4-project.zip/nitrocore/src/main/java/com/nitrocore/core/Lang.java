package com.nitrocore.core;

import java.util.HashMap;
import java.util.Map;

/** English and Russian texts. Missing keys fall back to English and then to the key itself. */
public final class Lang {

	private static final Map<String, String[]> TEXTS = new HashMap<>();
	private static volatile boolean russian;

	private Lang() {
	}

	public static void setRussian(boolean value) {
		russian = value;
	}

	public static boolean isRussian() {
		return russian;
	}

	public static String t(String key) {
		String[] pair = TEXTS.get(key);
		if (pair == null) {
			return key;
		}
		if (russian && pair[1] != null && !pair[1].isEmpty()) {
			return pair[1];
		}
		return pair[0];
	}

	public static boolean has(String key) {
		return TEXTS.containsKey(key);
	}

	private static void p(String key, String en, String ru) {
		TEXTS.put(key, new String[] {en, ru});
	}

	static {
		p("tab.home", "Home", "Главная");
		p("tab.cull", "Culling", "Отсечение");
		p("tab.adapt", "Adaptive", "Адаптив");
		p("tab.tweaks", "Tweaks", "Опции");
		p("tab.hud", "HUD", "HUD");
		p("tab.style", "Style", "Стиль");
		p("tab.about", "About", "Инфо");

		p("on", "ON", "ВКЛ");
		p("off", "OFF", "ВЫКЛ");
		p("close", "Close", "Закрыть");
		p("u.blocks", "blocks", "бл.");
		p("u.chunks", "chunks", "чанков");
		p("distance", "Distance", "Дистанция");

		p("h.presets", "Presets", "Пресеты");
		p("home.presetnote", "A preset rewrites every optimization setting. Your colours and interface options stay.", "Пресет перезаписывает все настройки оптимизации. Цвета и параметры интерфейса остаются.");
		p("master.label", "NitroCore enabled", "NitroCore включён");
		p("master.desc", "Off hands your own options back", "Выключено: вернёт твои настройки");
		p("h.status", "Status", "Состояние");
		p("st.adapt", "Adaptive level", "Адаптивный уровень");
		p("st.fps", "Frame rate", "Кадров в секунду");
		p("st.mem", "Memory after cleanup", "Память после очистки");
		p("st.hook.entity", "Entity culling hook", "Хук сущностей");
		p("st.hook.be", "Block entity hook", "Хук блочных сущностей");
		p("st.hook.particle", "Particle hook", "Хук частиц");
		p("st.hook.splash", "Loading bar hook", "Хук полосы загрузки");
		p("st.hook.loading", "World loading hook", "Хук загрузки мира");
		p("st.active", "active", "работает");
		p("st.wait", "waiting", "ждёт");
		p("st.na", "n/a", "н/д");
		p("home.hooknote", "Waiting means the hook has not run yet, for example nothing to cull in view. If it stays waiting in a busy world, another mod bypasses it.", "Ждёт значит хук ещё не срабатывал, например нечего скрывать. Если в насыщенном мире всё ещё ждёт, его обходит другой мод.");

		p("h.entities", "Entities", "Сущности");
		p("cull.all", "Cull far entities", "Скрывать далёкие сущности");
		p("cull.alldesc", "Skips drawing what is beyond the distances below", "Не рисует то, что дальше указанных дистанций");
		p("cull.mobs", "Mobs", "Мобы");
		p("cull.items", "Dropped items", "Предметы на земле");
		p("cull.xp", "Experience orbs", "Шарики опыта");
		p("cull.proj", "Projectiles", "Снаряды");
		p("cull.stands", "Armor stands", "Стойки для брони");
		p("cull.decor", "Frames and paintings", "Рамки и картины");
		p("cull.other", "Other entities", "Прочие сущности");
		p("cull.note", "Players, glowing entities, riders and anything very large are never hidden.", "Игроки, светящиеся сущности, всадники и очень крупные существа не скрываются.");
		p("h.blockents", "Block entities", "Блочные сущности");
		p("be.all", "Cull far block entities", "Скрывать далёкие блочные сущности");
		p("be.alldesc", "Chests, furnaces and similar. Beacons and portals stay.", "Сундуки, печи и подобное. Маяки и порталы остаются.");
		p("be.small", "Cull signs, banners, heads", "Скрывать таблички, флаги, головы");
		p("h.particles", "Particles", "Частицы");
		p("pt.dist", "Drop far particles", "Не создавать далёкие частицы");
		p("pt.cap", "Limit particle count", "Ограничить число частиц");
		p("pt.capval", "Maximum particles", "Максимум частиц");

		p("ad.on", "Adaptive quality", "Адаптивное качество");
		p("ad.ondesc", "Steps quality down only while FPS is under target", "Снижает качество, только пока FPS ниже цели");
		p("ad.target", "Target FPS", "Целевой FPS");
		p("ad.rd", "Lower render distance", "Снижать дальность прорисовки");
		p("ad.mind", "Lowest render distance", "Минимальная дальность");
		p("ad.ent", "Lower entity distance", "Снижать дальность сущностей");
		p("ad.part", "Lower particles", "Снижать частицы");
		p("ad.cloud", "Drop clouds", "Убирать облака");
		p("ad.note", "Level 1 trims particles and clouds, level 2 adds entity distance and 2 chunks of render distance, levels 3 and 4 go further. It steps down after 3 seconds under target and steps back up slowly. Your own values come back when the game runs well again.", "Уровень 1 урезает частицы и облака, уровень 2 добавляет дальность сущностей и минус 2 чанка, уровни 3 и 4 идут дальше. Падение качества через 3 секунды ниже цели, возврат медленный. Твои значения возвращаются, когда игра снова идёт хорошо.");
		p("ad.now", "Current level", "Текущий уровень");

		p("tw.blur", "Disable menu blur", "Отключить размытие меню");
		p("tw.blurdesc", "Skips a blur pass behind every menu", "Убирает проход размытия за меню");
		p("tw.shadows", "No entity shadows", "Без теней сущностей");
		p("tw.clouds", "Clouds off", "Облака выключены");
		p("tw.particles", "Reduced particles", "Меньше частиц");
		p("tw.biome", "Cap biome blend", "Ограничить смешивание биомов");
		p("tw.biomeval", "Maximum biome blend", "Макс. смешивание биомов");
		p("tw.note", "These write the normal game options. Turning one off gives your own value back. Changing biome blend rebuilds loaded chunks once.", "Это обычные настройки игры. Выключишь — вернётся твоё значение. Смена смешивания биомов один раз перестраивает загруженные чанки.");

		p("hud.on", "Show HUD", "Показывать HUD");
		p("hud.corner", "Corner", "Угол");
		p("hud.tl", "Top left", "Сверху слева");
		p("hud.tr", "Top right", "Сверху справа");
		p("hud.bl", "Bottom left", "Снизу слева");
		p("hud.br", "Bottom right", "Снизу справа");
		p("hud.opacity", "Opacity", "Прозрачность");
		p("hud.showframe", "Frame time", "Время кадра");
		p("hud.showlows", "Average and 1% low", "Средний и 1% low");
		p("hud.showmem", "Memory", "Память");
		p("hud.showent", "Entities and particles", "Сущности и частицы");
		p("hud.showlvl", "Adaptive level", "Адаптивный уровень");
		p("hud.warn", "Low memory warning", "Предупреждение о нехватке памяти");
		p("hud.warnpct", "Warn at", "Предупреждать при");
		p("hud.note", "The HUD only measures while it is shown.", "HUD измеряет только пока он показан.");
		p("hud.frame", "Frame", "Кадр");
		p("hud.mem", "RAM", "ОЗУ");
		p("hud.ent", "Ent", "Сущн.");
		p("hud.part", "Part", "Част.");
		p("hud.adapt", "Adapt", "Адапт");
		p("mem.warn", "Memory is nearly full after cleanup. Raise the heap in your launcher.", "Память почти заполнена. Увеличь объём памяти в лаунчере.");

		p("h.theme", "Theme", "Тема");
		p("st.accent", "Accent colour", "Цвет акцента");
		p("st.bg", "Background colour", "Цвет фона");
		p("st.text", "Text colour", "Цвет текста");
		p("st.alpha", "Panel opacity", "Непрозрачность панели");
		p("st.radius", "Corner radius", "Скругление углов");
		p("h.interface", "Interface", "Интерфейс");
		p("st.anim", "Animations", "Анимации");
		p("st.lite", "Lite interface", "Лёгкий интерфейс");
		p("st.litedesc", "No animations or rounded corners, easiest on weak devices", "Без анимаций и скруглений, легче всего для слабых устройств");
		p("st.touch", "Touch mode", "Режим касаний");
		p("st.touchdesc", "Bigger rows and handles for phones", "Крупные строки и ползунки для телефонов");
		p("st.button", "Menu button on title and pause", "Кнопка меню на заголовке и паузе");
		p("h.loading", "Loading screens", "Экраны загрузки");
		p("st.splash", "Styled loading bar", "Стильная полоса загрузки");
		p("st.loading", "Styled world loading screen", "Стильный экран загрузки мира");
		p("st.lang", "Language", "Язык");
		p("st.langauto", "Auto", "Авто");
		p("st.key", "Open key is Right Shift. Change it in Controls. On a phone use the NitroCore button.", "Клавиша открытия: правый Shift. Меняется в управлении. На телефоне используй кнопку NitroCore.");

		p("ab.author", "Author: Я", "Автор: Я");
		p("ab.desc", "Client side performance toolkit for Fabric 1.21.4. It only hides what is far away, tunes the normal options on demand and never changes how the game plays.", "Клиентский набор оптимизаций для Fabric 1.21.4. Он только скрывает далёкое, настраивает обычные опции по необходимости и не меняет игровой процесс.");
		p("h.jvm", "Memory and launcher", "Память и лаунчер");
		p("ab.heap", "Game memory limit", "Лимит памяти игры");
		p("ab.heaplow", "Under 2 GB. Raise it in the launcher if the device allows.", "Меньше 2 ГБ. Увеличь в лаунчере, если устройство позволяет.");
		p("ab.heapok", "The limit looks reasonable. Do not give the game all of your RAM.", "Лимит выглядит разумно. Не отдавай игре всю оперативную память.");
		p("ab.flags", "A common starting point for the launcher arguments: -XX:+UseG1GC -XX:MaxGCPauseMillis=100 -XX:+ParallelRefProcEnabled. The mod does not measure these. Phone launchers may ignore them.", "Обычная отправная точка для аргументов лаунчера: -XX:+UseG1GC -XX:MaxGCPauseMillis=100 -XX:+ParallelRefProcEnabled. Мод их не измеряет. Лаунчеры на телефоне могут их игнорировать.");
		p("h.reset", "Reset", "Сброс");
		p("ab.resetopt", "Back to the Balanced preset", "Вернуть пресет Баланс");
		p("load.world", "Loading world", "Загрузка мира");
		p("ab.resetall", "Reset every setting", "Сбросить все настройки");
	}
}
