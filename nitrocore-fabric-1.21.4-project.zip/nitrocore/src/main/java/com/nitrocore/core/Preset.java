package com.nitrocore.core;

/** One-click bundles of the optimization settings. Interface and theme settings are never touched. */
public enum Preset {
	QUALITY("Quality", "Качество"),
	BALANCED("Balanced", "Баланс"),
	PERFORMANCE("Performance", "Производительность"),
	ULTRA_LITE("Ultra lite", "Ультра-лёгкий"),
	MOBILE("Mobile", "Телефон");

	public final String en;
	public final String ru;

	Preset(String en, String ru) {
		this.en = en;
		this.ru = ru;
	}

	public static Preset byName(String name) {
		for (Preset p : values()) {
			if (p.name().equalsIgnoreCase(name)) {
				return p;
			}
		}
		return BALANCED;
	}

	public void apply(Config c) {
		c.resetOptimizationDefaults();
		switch (this) {
			case QUALITY -> {
				c.distMobs = 160;
				c.distItems = 80;
				c.distXp = 48;
				c.distProjectiles = 96;
				c.distArmorStands = 96;
				c.distDecor = 96;
				c.distOther = 192;
				c.distBlockEntities = 64;
				c.distSmallBlockEntities = 40;
				c.distParticles = 64;
				c.particleCap = 5000;
				c.adaptive = false;
				c.forceMenuBlurOff = false;
			}
			case BALANCED -> {
				// the field defaults are the balanced profile
			}
			case PERFORMANCE -> {
				c.distMobs = 72;
				c.distItems = 32;
				c.distXp = 24;
				c.distProjectiles = 48;
				c.distArmorStands = 40;
				c.distDecor = 40;
				c.distOther = 96;
				c.distBlockEntities = 40;
				c.distSmallBlockEntities = 16;
				c.distParticles = 28;
				c.particleCap = 1500;
				c.targetFps = 75;
				c.adaptiveMinDistance = 5;
				c.forceEntityShadowsOff = true;
				c.reduceParticles = true;
			}
			case ULTRA_LITE -> {
				c.distMobs = 48;
				c.distItems = 24;
				c.distXp = 16;
				c.distProjectiles = 32;
				c.distArmorStands = 24;
				c.distDecor = 24;
				c.distOther = 64;
				c.distBlockEntities = 24;
				c.distSmallBlockEntities = 12;
				c.distParticles = 20;
				c.particleCap = 700;
				c.targetFps = 60;
				c.adaptiveMinDistance = 4;
				c.forceEntityShadowsOff = true;
				c.forceCloudsOff = true;
				c.reduceParticles = true;
				c.capBiomeBlend = true;
				c.biomeBlendMax = 1;
			}
			case MOBILE -> {
				c.distMobs = 56;
				c.distItems = 24;
				c.distXp = 16;
				c.distProjectiles = 32;
				c.distArmorStands = 24;
				c.distDecor = 24;
				c.distOther = 64;
				c.distBlockEntities = 24;
				c.distSmallBlockEntities = 12;
				c.distParticles = 20;
				c.particleCap = 600;
				c.targetFps = 30;
				c.adaptiveMinDistance = 3;
				c.forceEntityShadowsOff = true;
				c.forceCloudsOff = true;
				c.reduceParticles = true;
				c.capBiomeBlend = true;
				c.biomeBlendMax = 1;
			}
		}
		c.preset = name();
		c.sanitize();
	}
}
