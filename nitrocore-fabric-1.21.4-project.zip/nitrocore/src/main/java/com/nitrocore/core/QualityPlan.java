package com.nitrocore.core;

/**
 * Turns the user's own option values (the baseline), the config and the adaptive level into the
 * option values that should be active. Pure arithmetic, so it can be checked without the game.
 */
public final class QualityPlan {

	private QualityPlan() {
	}

	public static final int PARTICLES_ALL = 0;
	public static final int PARTICLES_DECREASED = 1;
	public static final int PARTICLES_MINIMAL = 2;

	public static final int CLOUDS_OFF = 0;
	public static final int CLOUDS_FAST = 1;
	public static final int CLOUDS_FANCY = 2;

	public static final class State {
		public int viewDistance = 12;
		public double entityScale = 1.0;
		public int particles = PARTICLES_ALL;
		public int clouds = CLOUDS_FANCY;
		public boolean shadows = true;
		public int biomeBlend = 2;
		public int blur = 5;

		public State copy() {
			State s = new State();
			s.viewDistance = viewDistance;
			s.entityScale = entityScale;
			s.particles = particles;
			s.clouds = clouds;
			s.shadows = shadows;
			s.biomeBlend = biomeBlend;
			s.blur = blur;
			return s;
		}

		public boolean sameAs(State o) {
			return viewDistance == o.viewDistance
				&& Math.abs(entityScale - o.entityScale) < 1.0E-6
				&& particles == o.particles
				&& clouds == o.clouds
				&& shadows == o.shadows
				&& biomeBlend == o.biomeBlend
				&& blur == o.blur;
		}
	}

	private static final int[] DISTANCE_DROP = {0, 0, 2, 4, 6};
	private static final double[] ENTITY_SCALE_CAP = {Double.MAX_VALUE, Double.MAX_VALUE, 1.0, 0.75, 0.5};

	public static State compute(Config c, State base, int level) {
		State t = base.copy();
		if (!c.enabled) {
			return t;
		}
		if (c.forceMenuBlurOff) {
			t.blur = 0;
		}
		if (c.forceEntityShadowsOff) {
			t.shadows = false;
		}
		if (c.capBiomeBlend) {
			t.biomeBlend = Math.min(t.biomeBlend, c.biomeBlendMax);
		}
		if (c.forceCloudsOff) {
			t.clouds = CLOUDS_OFF;
		}
		if (c.reduceParticles) {
			t.particles = Math.max(t.particles, PARTICLES_DECREASED);
		}
		int lv = Math.max(0, Math.min(Governor.MAX_LEVEL, level));
		if (c.adaptive && lv > 0) {
			if (c.adaptiveParticles) {
				t.particles = Math.max(t.particles, PARTICLES_DECREASED);
				if (lv >= 3) {
					t.particles = PARTICLES_MINIMAL;
				}
			}
			if (c.adaptiveClouds) {
				if (lv >= 2) {
					t.clouds = CLOUDS_OFF;
				} else {
					t.clouds = Math.min(t.clouds, CLOUDS_FAST);
				}
			}
			if (c.adaptiveEntities) {
				t.entityScale = Math.min(t.entityScale, ENTITY_SCALE_CAP[lv]);
			}
			if (c.adaptiveRenderDistance) {
				int floor = Math.min(c.adaptiveMinDistance, base.viewDistance);
				t.viewDistance = Math.max(floor, base.viewDistance - DISTANCE_DROP[lv]);
			}
		}
		return t;
	}
}
