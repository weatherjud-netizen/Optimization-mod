package com.nitrocore.core;

/** Every colour the menu draws with, derived from the three base colours and the panel alpha. */
public final class Theme {

	public final int dim;
	public final int panel;
	public final int panelRaised;
	public final int panelHover;
	public final int border;
	public final int accent;
	public final int accentHover;
	public final int accentSoft;
	public final int text;
	public final int textDim;
	public final int onAccent;
	public final int good;
	public final int warn;
	public final int bad;
	public final boolean light;

	private Theme(Config c) {
		int bg = c.bgColor & 0xFFFFFF;
		int acc = c.accentColor & 0xFFFFFF;
		int txt = c.textColor & 0xFFFFFF;
		light = Colors.luminance(bg) > 0.55f;
		float lift = light ? -0.05f : 0.05f;
		int alpha = c.panelAlpha;

		dim = Colors.argb(light ? 150 : 170, 0x000000);
		panel = Colors.argb(alpha, bg);
		panelRaised = Colors.argb(alpha, shift(bg, lift));
		panelHover = Colors.argb(alpha, shift(bg, lift * 2.2f));
		border = Colors.argb(255, Colors.mix(Colors.opaque(bg), Colors.opaque(acc), 0.38f) & 0xFFFFFF);
		accent = Colors.opaque(acc);
		accentHover = Colors.lighten(Colors.opaque(acc), 0.18f);
		accentSoft = Colors.argb(70, acc);
		text = Colors.opaque(txt);
		textDim = Colors.mix(Colors.opaque(txt), Colors.opaque(bg), 0.42f);
		onAccent = Colors.readableOn(acc);
		good = Colors.opaque(light ? 0x15803D : 0x4ADE80);
		warn = Colors.opaque(light ? 0xB45309 : 0xFBBF24);
		bad = Colors.opaque(light ? 0xB91C1C : 0xF87171);
	}

	public static Theme of(Config c) {
		return new Theme(c);
	}

	private static int shift(int rgb, float amount) {
		int argb = Colors.opaque(rgb);
		int out = amount >= 0f ? Colors.lighten(argb, amount) : Colors.darken(argb, -amount);
		return out & 0xFFFFFF;
	}
}
