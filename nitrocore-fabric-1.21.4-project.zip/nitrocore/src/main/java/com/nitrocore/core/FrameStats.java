package com.nitrocore.core;

import java.util.Arrays;

/** Rolling frame time window for the HUD: average and "1% low" frame rate. */
public final class FrameStats {

	private final float[] ring;
	private int count;
	private int head;
	private final float[] scratch;

	public FrameStats(int size) {
		ring = new float[size];
		scratch = new float[size];
	}

	public void record(float frameMs) {
		if (!(frameMs > 0f) || frameMs > 5000f) {
			return;
		}
		ring[head] = frameMs;
		head = (head + 1) % ring.length;
		if (count < ring.length) {
			count++;
		}
	}

	public int samples() {
		return count;
	}

	public float lastMs() {
		if (count == 0) {
			return 0f;
		}
		return ring[(head - 1 + ring.length) % ring.length];
	}

	public float averageMs() {
		if (count == 0) {
			return 0f;
		}
		double sum = 0;
		for (int i = 0; i < count; i++) {
			sum += ring[i];
		}
		return (float) (sum / count);
	}

	/** Frame rate of the slowest 1% of frames in the window (at least the single slowest frame). */
	public float onePercentLowFps() {
		if (count == 0) {
			return 0f;
		}
		System.arraycopy(ring, 0, scratch, 0, count);
		Arrays.sort(scratch, 0, count);
		int worst = Math.max(1, count / 100);
		double sum = 0;
		for (int i = count - worst; i < count; i++) {
			sum += scratch[i];
		}
		float ms = (float) (sum / worst);
		return ms <= 0f ? 0f : 1000f / ms;
	}

	public float averageFps() {
		float ms = averageMs();
		return ms <= 0f ? 0f : 1000f / ms;
	}
}
