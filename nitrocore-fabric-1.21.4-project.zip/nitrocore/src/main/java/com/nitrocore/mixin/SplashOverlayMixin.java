package com.nitrocore.mixin;

import com.nitrocore.client.ConfigStore;
import com.nitrocore.client.LoadingArt;
import com.nitrocore.client.MixinStatus;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SplashOverlay.class)
public abstract class SplashOverlayMixin {

	@Shadow
	private float progress;

	// only the bar is replaced, the fade and the logo stay vanilla so the overlay still finishes on its own
	@Inject(method = "renderProgressBar", at = @At("HEAD"), cancellable = true)
	private void nitrocore$styledBar(DrawContext context, int minX, int minY, int maxX, int maxY, float opacity, CallbackInfo ci) {
		if (!ConfigStore.get().splashBar) {
			return;
		}
		MixinStatus.hit(MixinStatus.SPLASH);
		LoadingArt.bar(context, minX, minY, maxX, maxY, this.progress, opacity);
		ci.cancel();
	}
}
