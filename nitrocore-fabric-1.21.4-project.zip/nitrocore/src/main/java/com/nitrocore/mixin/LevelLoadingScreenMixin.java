package com.nitrocore.mixin;

import com.nitrocore.client.ConfigStore;
import com.nitrocore.client.LoadingArt;
import com.nitrocore.client.MixinStatus;
import com.nitrocore.core.Config;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.world.LevelLoadingScreen;
import net.minecraft.server.WorldGenerationProgressTracker;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelLoadingScreen.class)
public abstract class LevelLoadingScreenMixin {

	@Shadow
	@Final
	private WorldGenerationProgressTracker progressProvider;

	@Inject(method = "render", at = @At("HEAD"), cancellable = true)
	private void nitrocore$styledLoading(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
		Config c = ConfigStore.get();
		if (!c.enabled || !c.customLoading || this.progressProvider == null) {
			return;
		}
		MixinStatus.hit(MixinStatus.LOADING);
		LoadingArt.worldLoading(context, this.progressProvider.getProgressPercentage());
		ci.cancel();
	}
}
