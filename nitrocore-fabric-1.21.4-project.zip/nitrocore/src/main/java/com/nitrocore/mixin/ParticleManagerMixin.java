package com.nitrocore.mixin;

import com.nitrocore.client.ConfigStore;
import com.nitrocore.client.CullRuntime;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import java.util.Queue;

@Mixin(ParticleManager.class)
public abstract class ParticleManagerMixin {

	@Shadow
	private Map<ParticleTextureSheet, Queue<Particle>> particles;

	@Inject(
		method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
		at = @At("HEAD"),
		cancellable = true
	)
	private void nitrocore$dropFarOrExcessParticles(ParticleEffect effect, double x, double y, double z, double vx, double vy, double vz, CallbackInfoReturnable<Particle> cir) {
		int live = 0;
		if (ConfigStore.get().capParticles) {
			for (Queue<Particle> queue : this.particles.values()) {
				live += queue.size();
			}
		}
		if (CullRuntime.cullParticle(x, y, z, live)) {
			cir.setReturnValue(null);
		}
	}
}
