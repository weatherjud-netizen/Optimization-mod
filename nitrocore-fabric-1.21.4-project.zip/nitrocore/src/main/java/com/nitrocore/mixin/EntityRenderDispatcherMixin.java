package com.nitrocore.mixin;

import com.nitrocore.client.CullRuntime;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {

	// a plain head injection, so it stacks with other mods that touch the same method
	@Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
	private void nitrocore$cullFarEntities(Entity entity, Frustum frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
		if (CullRuntime.cullEntity(entity, x, y, z)) {
			cir.setReturnValue(false);
		}
	}
}
