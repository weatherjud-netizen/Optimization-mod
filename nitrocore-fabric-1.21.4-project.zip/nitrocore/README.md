# NitroCore

Client side performance toolkit for Fabric 1.21.4. Author: Я.

What it does, all of it switchable in the menu (Right Shift in game, or the NitroCore button on the title and pause screens, or the config button in Mod Menu):

- distance culling for entities (mobs, items, experience orbs, projectiles, armor stands, frames), block entities and particles
- particle count cap
- adaptive quality: steps particles, clouds, entity distance and render distance down only while FPS is under your target, and gives your values back afterwards
- fixed tweaks: no menu blur, no entity shadows, clouds off, reduced particles, biome blend cap
- live HUD with FPS, average, 1% low, frame time, memory, entities, particles, adaptive level
- low memory warning based on memory left after garbage collection
- styled loading bar and world loading screen
- fully themeable menu: presets, colour pickers, opacity, corner radius, lite mode, touch mode, English and Russian

It never changes gameplay and only hides things that are far away. It uses plain injections and coexists with Sodium and similar mods; the Home tab shows whether each hook has actually run.

## Build

GitHub: push this folder to a repository, open the Actions tab, run the `build` workflow. The jar is in the artifact `nitrocore-jar` (use the file without `-sources`).

Local: JDK 25 (or the JDK your Loom version asks for), then `./gradlew build`. The jar ends up in `build/libs`.

## Versions

Minecraft 1.21.4, Yarn 1.21.4+build.8, Fabric Loader 0.20.1, Fabric API 0.119.4+1.21.4, Loom 1.19-SNAPSHOT, Mod Menu 13.0.4 (optional at runtime).
